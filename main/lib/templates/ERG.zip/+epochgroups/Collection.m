classdef Collection < symphonyui.core.persistent.descriptions.EpochGroupDescription
  
  methods
    
    function obj = Collection()
      import symphonyui.core.PropertyType;
      
      obj.addProperty('summary', '',...
        'description', 'Describe, briefly, the purpose of this block.');
      
      obj.addProperty('externalSolutionControl', '',...
        'description', 'List the control bath constituents. eg AMES');
      
      obj.addProperty('externalSolutionDrug', '',...
        'description', 'List drugs applied, if applicable. eg isradipine.');
      
      obj.addProperty('externalSolutionWash', '',...
        'description', 'List wash constituents if used in this group. eg AMES');
      
      todaysDate = datestr(now,'DD-mmm-YYYY');
      obj.addProperty('solutionsDateCreated', todaysDate, ...
        'type', PropertyType('char', 'row', 'datestr'), ...
        'description', 'Date solutions were made.' ...
        );
      
      obj.addAllowableParentType([]); % cannot nest collections.
    end
    
  end
end
