classdef LedPulseOnBackground < admin.core.LEDProtocol
  % LEDPULSEONBACKGROUND Presents LED pulse on a epoch-by-epoch background
  % Can only present backgrounds on led2 (if led2 does not exist, this
  % protocol is invalid.
  
  
  %% LED Controls
  properties
    stimAmplitudes = 0.015 % Stimuslus Amplitudes (V) *row*
    bgAmplitudes = 0 % Background Amplitudes (V) *row*
  end
  
  %% Temporal Controls
  properties
    preTime = 200                % Leadin duration prior to stimulus (ms) *scalar*
    stimTime = 20                % Stim duration for LED pulse/step *matrix*
    tailTime = 1380              % Leadout duration after stimulus end (ms) *matrix*
  end
  properties (Dependent)
    totalEpochTime               % Total epoch duration (ms)
  end
  %% Repeating behavior
  properties
    % ASFAMILY - Changes the ordering of the epochs. A value of false will cause
    % each flash to repeat NUMBEROFAVERAGES times before moving to the next.
    asFamily = true
    numberInFamily = uint16(1)   % Number of pulses in family
  end
  %% Display Controls
  properties (Hidden)
    stimAmplitudesType
    bgAmplitudesType
    backgroundDeviceType
    stimTimeType
    tailTimeType
    numberInFamilyType
  end
  %% Other Properties
  
  %% Override Methods
  methods
    
    function didSetRig(obj)
      import symphonyui.core.PropertyType;
      % call the superclass method
      didSetRig@admin.core.LEDProtocol(obj);
      % set types
      obj.numberInFamilyType = PropertyType('uint16', 'scalar',[1,Inf]);
      obj.stimTimeType = PropertyType('denserealdouble','row');
      obj.tailTimeType = PropertyType('denserealdouble','row');
      obj.stimAmplitudesType = PropertyType('denserealdouble','row');
      obj.bgAmplitudesType = PropertyType('denserealdouble','row');
    end
    
    function setProperty(obj, name, value)
      switch name
        case 'numberInFamily'
          setProperty@admin.core.LEDProtocol(obj, name, uint16(value));
          % use the setproperty method for stim and tail times to automatically
          % adjust their lengths
          for prop = ["tailTime","stimTime","stimAmplitudes","bgAmplitudes","delayBetweenEpochs"]
            pval = obj.getProperty(char(prop));
            obj.setProperty(char(prop),pval);
          end
          % we have already set the value, we can return from here
          return
        case {'tailTime','stimTime','delayBetweenEpochs'}
          value = obj.validateLength(value);
        case 'stimAmplitudes'
          value = obj.trimAmplitudes(obj.led1,value);
          value = obj.validateLength(value);
        case 'bgAmplitudes'
          value = obj.trimAmplitudes(obj.led2,value);
          value = obj.validateLength(value);
      end
      % finally, set the property in the superclass
      setProperty@admin.core.LEDProtocol(obj, name, value);
    end
    
    function p = getPreview(obj, panel)
      p = symphonyui.builtin.previews.StimuliPreview(panel, ...
        @()createPreviewStimuli(obj));
      function s = createPreviewStimuli(obj)
        s = cell(1, obj.numberInFamily);
        for i = 1:numel(s)
          s{i} = obj.createLedStimulus(i);
        end
      end
    end
    
    function prepareRun(obj)
      prepareRun@admin.core.LEDProtocol(obj);
      
      hAmp = obj.rig.getDevice(obj.amp);
      cm = admin.utils.getColorShades(1,obj.numberInFamily,true);
      cm = permute(cm,[3,2,1]);% using single shades so squeeze into 2 dims
      
      obj.showFigure('admin.figures.Response', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'sweepColor', cm(1,:) ...
        );
      obj.showFigure('admin.figures.MeanResponse', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'colormapping', cm, ...
        'showEach', true, ...
        'groupBy', {'lightAmplitude', 'stimDuration', 'backgroundAmplitude'} ...
        );
      if obj.monitorStimulus
        obj.showFigure('admin.figures.MeanResponse', ...
          obj.rig.getDevice(obj.led1), ...
          'instanceId', 'Led_Monitor', ...
          'colormapping', cm, ...
          'showEach', true, ...
          'groupBy', {'lightAmplitude', 'stimDuration', 'backgroundAmplitude'} ...
          );
      end
      if obj.monitorBackground
        obj.showFigure('admin.figures.MeanResponse', ...
          obj.rig.getDevice(obj.led2), ...
          'instanceId', 'Led_Monitor_2', ...
          'colormapping', cm, ...
          'showEach', true, ...
          'groupBy', {'lightAmplitude', 'stimDuration', 'backgroundAmplitude'} ...
          );
      end
    end
    
    function prepareEpoch(obj, epoch)
      import symphonyui.core.Measurement
      prepareEpoch@admin.core.LEDProtocol(obj, epoch);
      
      if obj.asFamily
        pulseNum = mod(obj.numEpochsPrepared - 1, obj.numberInFamily) + 1;
      else
        % create a vector of 1:numberInFamily each element repeated numAverages
        Indices = admin.utils.rep( ...
          (1:obj.numberInFamily)', ...
          1, ...
          obj.numberOfAverages ...
          );
        % pulsenum is the current position in the indices vector
        pulseNum = Indices(obj.numEpochsPrepared);
      end
      
      stim = obj.createLedStimulus(pulseNum);
      stimProps = stim.parameters;
      bgAmp = obj.bgAmplitudes(pulseNum);
      
      epoch.addParameter('lightAmplitude', stimProps('amplitude'));
      epoch.addParameter('stimDuration', stimProps('stimTime'));
      epoch.addParameter('backgroundAmplitude',bgAmp);
      
      lDevice = obj.rig.getDevice(obj.led1);
      epoch.addStimulus(lDevice, stim);
      
      % set this epoch background
      bgDevice = obj.rig.getDevice(obj.led2);
      bgVal = Measurement( ...
        bgAmp, ...
        bgDevice.background.displayUnits ...
        );
      epoch.setBackground(bgDevice,bgVal);
      
      % record response on amplifier
      epoch.addResponse(obj.rig.getDevice(obj.amp));
    end
    
    function prepareInterval(obj, interval)
      import symphonyui.core.Measurement
      prepareInterval@admin.core.LEDProtocol(obj, interval);
      if obj.asFamily
        pulseNum = mod(obj.numEpochsPrepared - 1, obj.numberInFamily) + 1;
      else
        % create a vector of 1:numberInFamily each element repeated numAverages
        Indices = admin.utils.rep( ...
          (1:obj.numberInFamily)', ...
          1, ...
          obj.numberOfAverages ...
          );
        % pulsenum is the current position in the indices vector
        pulseNum = Indices(obj.numEpochsPrepared);
      end
      % ensure the led background light persists through epoch intervals (does
      % this cause a double bg value
      device = obj.rig.getDevice(obj.led1);
      interval.addDirectCurrentStimulus( ...
        device, ...
        device.background, ... 
        obj.delayBetweenEpochs(pulseNum) * 1e-3, ... % convert from ms to sec for dc stim
        obj.sampleRate ...
        );
      bgDevice = obj.rig.getDevice(obj.led2);
      bgVal = Measurement( ...
        obj.bgAmplitudes(pulseNum), ...
        bgDevice.background.displayUnits ...
        );
      interval.addDirectCurrentStimulus( ...
        bgDevice, ...
        bgVal, ... 
        obj.delayBetweenEpochs(pulseNum) * 1e-3, ... % convert from ms to sec for dc stim
        obj.sampleRate ...
        );
    end
    
    function completeEpoch(obj,epoch)
      completeEpoch@admin.core.LEDProtocol(obj,epoch);
    end
    
    function completeRun(obj)
      completeRun@admin.core.LEDProtocol(obj);
    end
    
    function tf = shouldContinuePreparingEpochs(obj)
      tf = obj.numEpochsPrepared < obj.numberOfAverages * obj.numberInFamily;
    end
    
    function tf = shouldContinueRun(obj)
      tf = obj.numEpochsCompleted < obj.numberOfAverages * obj.numberInFamily;
    end
    
  end
  
  %% Helper Methods
  methods
    %% set/get
    function t = get.totalEpochTime(obj)
      t = obj.tailTime + obj.preTime + obj.stimTime;
    end
    
    %% Custom Routines
    function stim = createLedStimulus(obj, pulseNum)
      persistent LED;
      if isempty(LED)
        LED = obj.rig.getDevice(obj.led1);
      elseif ~isempty(LED) && ~isequal(LED.name,obj.led1)
        LED = obj.rig.getDevice(obj.led1);
      end
      
      lightAmplitude = obj.stimAmplitudes(pulseNum);
      
      
      gen = symphonyui.builtin.stimuli.PulseGenerator();
      
      gen.preTime = obj.preTime;
      gen.stimTime = obj.stimTime(pulseNum);
      gen.tailTime = obj.tailTime(pulseNum);
      gen.amplitude = lightAmplitude;
      gen.mean = LED.background.quantity;
      gen.sampleRate = obj.sampleRate;
      gen.units = LED.background.displayUnits;
      
      stim = gen.generate();
    end
    
  end
  
  
  methods
  %%% Validation
    function value = validateLength(obj,value)
      n = obj.numberInFamily;
      nval = numel(value);
      if n > nval
        value(end+(1:(n-nval))) = value(end);
      elseif n < nval
        value((n+1):end) = [];
      end
    end
    
    function value = trimAmplitudes(obj,ledName,value)
      led = obj.rig.getDevice(ledName);
      n = numel(value);
      tf = true(n,1);
      for a = 1:n
        ap = value(a);
        if isa(led,'admin.devices.LedDevice')
          tf(a) = led.canAcceptVoltage(ap);
        else
          try %#ok<TRYNC>
            maxV = led.getResource('maximum');
            tf(a) = (0 <= ap) && (ap <= maxV);
          end
        end
      end
      value = value(tf);
    end
    
  end
  
  %% Other Administrative Methods
  methods
    
    function d = getPropertyDescriptor(obj, name)
      % GETPROPERTYDESCRIPTOR Override to control category on property grid
      d = getPropertyDescriptor@admin.core.LEDProtocol(obj,name);
      switch name
        case 'bgAmplitudes'
          d.category = '2. Stimulus Control';
      end
      
      %{      
      switch name
        case RecordControl
          d.category = '1. Recording Control';
          %%%
        case 'bgAmplitudes'
          d.category = '2. Stimulus Control';
          %%%
        case TemporalControl
          d.category = '3. Temporal Controls';
          %%%
        case RepControl
          d.category = '4. Repetition Control';
          %%%
        otherwise % don't update
          %%%
      end
      %}
    end
    
    function [tf, msg] = isValid(obj)
      msg = [];
      try
        tf = obj.nLeds > 1;
      catch
        tf = false;
      end
      if ~tf
        msg = 'Protocl does not contain enough LED devices.';
      end
    end
    
  end
end