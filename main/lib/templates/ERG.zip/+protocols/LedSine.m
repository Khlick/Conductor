classdef LedSine < admin.core.LEDProtocol
  %% LED Controls
  
  properties
    monitorBackground = true % Set to true to record background LED and display.
    lightAmplitude = 0.8  % Height above center amplitude of the output light
    phaseShift = 0        % Phase angle to start sine (in radians; eg. pi/2)
    oscillationCenter = 0.8% Background intensity (V) (signal is bg+/-(peak-bg)
  end
  %% Temporal Controls
  properties
    preTime = 200                % Leadin duration prior to stimulus (ms)
    stimTime = 500               % Stim duration for LED pulse/step
    totalEpochTime = 2000        % Total epoch duration (ms)
  end
  properties (Dependent)
    tailTime                     % Leadout duration after stimulus end (ms)
  end
  %% Repeating behavior
  properties
    stimulationFrequency  = 5    % How many cycles per second? (Hz)
    asFamily = true                 % As family (1:nFam,1Lnfam...) or not (1,1,1,2,2,2,3...)
  end
  properties (Dependent)
    stimulationPeriod
    numberInFamily   % Total number of pulses in each family.
  end
  %% Display Controls
  properties (Hidden)
    asFamilyType
    lightAmplitudeType
    stimulationFrequencyType
  end
  
  %% Helper Properties
  properties (Dependent, Hidden)
    stimPattern
    linVec
  end
  %% Override Methods
  methods
    function didSetRig(obj)
      import symphonyui.core.PropertyType;
      
      didSetRig@admin.core.LEDProtocol(obj);
      
      obj.lightAmplitudeType = PropertyType('denserealdouble','matrix');
      obj.stimulationFrequencyType = PropertyType('denserealdouble','matrix');
      obj.asFamilyType = PropertyType('logical','scalar');
      % set monitor to true
      if isprop(obj,'monitorStimulus')
        obj.setProperty('monitorStimulus', true);
      end
    end
    
    function setProperty(obj, name, value)
      switch name
        case 'lightAmplitude'
          la = length(value);
          lf = length(obj.stimulationFrequency);
          if la > lf
            obj.stimulationFrequency(end:end+(la-lf)) = sampathlab.utils.rep(...
              obj.stimulationFrequency(end), (la-lf)+1, 'dims', {1,[]});
          elseif lf > la
            obj.stimulationFrequency = obj.stimulationFrequency(1:la);
          end
          maxV = double(obj.rig.getDevice(obj.led1).getResource('maximum'));
          currentBG = double(obj.rig.getDevice(obj.led1).background.quantity);
          for c = 1:length(value)
            checkValue = value(c);
            if (double(checkValue) + ...
                double(obj.oscillationCenter) +...
                currentBG) > maxV || ...
                (double(obj.oscillationCenter) - ...
                double(checkValue) + ...
                currentBG) < 0
              %fix if not within 0-maxV
              value(c) = min(maxV - double(obj.oscillationCenter) - currentBG, ...
                double(obj.oscillationCenter) - currentBG);
            end
          end
        case 'stimulationFrequency'
          lf = length(value);
          la = length(obj.lightAmplitude);
          if lf > la
            obj.lightAmplitude(end:end+(lf-la)) = sampathlab.utils.rep(...
              obj.lightAmplitude(end), (lf-la)+1, 'dims', {1,[]});
          elseif la > lf
            obj.lightAmplitude = obj.lightAmplitude(1:lf);
          end
        case 'oscillationCenter'
          maxV = double(obj.rig.getDevice(obj.led1).getResource('maximum'));
          currentBG = double(obj.rig.getDevice(obj.led1).background.quantity);
          maxAmpl = max(double(obj.lightAmplitude));
          if (double(value) + maxAmpl + currentBG) > maxV || ...
              (double(value) - maxAmpl + currentBG) < 0
            value = min(maxV - maxAmpl - currentBG,...
              maxAmpl - currentBG);
          end
        case 'delayBetweenEpochs'
          if ~isscalar(value)
            nVal = numel(value);
            nFam = obj.numberInFamily;
            if nVal > nFam
              value((nFam+1):end) = [];
            elseif nVal < nFam
              value(end + (1:(nFam-nVal))) = value(end);
            end
          end
      end
      setProperty@admin.core.LEDProtocol(obj, name, value);
    end
    
    function p = getPreview(obj, panel)
      p = admin.figures.stimPreview(panel, ...
        @()createPreviewStimuli(obj));
      function s = createPreviewStimuli(obj)
        s = arrayfun(@(x)obj.createLedStimulus(x),...
          1:obj.numberInFamily, 'unif',0);
        s = cat(1, s{:})';
      end
    end
    
    function prepareRun(obj)
      prepareRun@admin.core.LEDProtocol(obj);
      
      % Open figure handlers.
      hAmp = obj.rig.getDevice(obj.amp); % pointer to amplifier
      hLed = obj.rig.getDevice(obj.led1);
      hLed2 = obj.rig.getDevice(obj.led2);
      cm = admin.utils.getColorShades(1,obj.numberInFamily,false);
      cm = permute(cm,[3,2,1]);% using single shades so squeeze into 2 dims
      
      if obj.monitorStimulus
        obj.showFigure('admin.figures.MeanResponse', ...
          hLed, ...
          'instanceId', 'Led_Monitor', ...
          'colormapping', cm, ...
          'showEach', true, ...
          'groupBy', {'stimID'} ...
          );
      end
      if obj.monitorBackground
        obj.showFigure('admin.figures.MeanResponse', ...
          hLed2, ...
          'instanceId', 'Led_Monitor_2', ...
          'colormapping', cm, ...
          'showEach', true, ...
          'groupBy', {'stimID'} ...
          );
      end
      
      obj.showFigure( ...
        'admin.figures.Response',  ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'sweepColor', cm(1,:), ...
        'disableToolbar', true ...
        );
      
      obj.showFigure('admin.figures.MeanResponse', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'colormapping', cm, ...
        'showEach', true, ...
        'groupBy', {'stimID'} ...
        );
    end
    
    function prepareEpoch(obj, epoch)
      prepareEpoch@admin.core.LEDProtocol(obj, epoch);
      
      familyPulseNum = obj.linVec(obj.numEpochsPrepared);
      
      stim = obj.createLedStimulus(familyPulseNum);
      
      epoch.addParameter('stimID', ...
        sprintf('%s.%sV.%sHz',...
        matlab.lang.makeValidName(...
        obj.stimPattern{1}{familyPulseNum} ...
        ), ...
        num2str(obj.stimPattern{2}(familyPulseNum)), ...
        num2str(obj.stimPattern{4}(familyPulseNum)) ...
        )...
        );
      hLed2 = obj.rig.getDevice(obj.led2);
      epoch.addStimulus(obj.rig.getDevice(obj.led1), stim{1});
      epoch.addStimulus(hLed2, stim{2});
      epoch.addResponse(obj.rig.getDevice(obj.amp));
      if obj.monitorBackground
        epoch.addResponse(hLed2);
      end
    end
    
    function prepareInterval(obj, interval)
      prepareInterval@admin.core.LEDProtocol(obj, interval);
      
      if isscalar(obj.delayBetweenEpochs)
        delayDuration = obj.delayBetweenEpochs * 1e-3;
      else
        pulseNum = obj.linVec(obj.numIntervalsPrepared);
        delayDuration = obj.delayBetweenEpochs(pulseNum) * 1e-3;
      end
      
      device = obj.rig.getDevice(obj.led1);
      interval.addDirectCurrentStimulus( ...
        device, ...
        device.background, ...
        delayDuration, ...
        obj.sampleRate ...
        );
    end
    
    function completeEpoch(obj,epoch)
      completeEpoch@admin.core.LEDProtocol(obj,epoch);
    end
    
    function completeRun(obj)
      completeRun@admin.core.LEDProtocol(obj);
    end
    
    function tf = shouldContinuePreparingEpochs(obj)
      tf = obj.numEpochsPrepared < obj.numberOfAverages*obj.numberInFamily;
    end
    
    function tf = shouldContinueRun(obj)
      tf = obj.numEpochsCompleted < obj.numberOfAverages*obj.numberInFamily;
    end
    
  end
  %% Helper Methods
  methods
    %% set/get
    function t = get.tailTime(obj)
      t = obj.totalEpochTime - (obj.preTime + obj.stimTime);
      if t < 0
        obj.setProperty('totalEpochTime', abs(t))
        t=0;
      end
    end
    
    function p = get.stimulationPeriod(obj)
      p = 1e3./obj.stimulationFrequency;%in ms
    end
    
    function p = get.numberInFamily(obj)
      p = length(obj.lightAmplitude);
    end
    
    function pulseVec = get.linVec(obj)
      import admin.utils.rep;
      if obj.asFamily
        pulseVec = rep((1:obj.numberInFamily)',obj.numberOfAverages,1)';
      else
        pulseVec = rep((1:obj.numberInFamily),1,obj.numberOfAverages)';
      end
    end
    
    function s = get.stimPattern(obj)
      s = cell(1,4);
      %device
      s{1} = admin.utils.rep( ...
        {obj.led1}, 1, obj.numberInFamily ...
        );
      %Amplitude
      s{2} = obj.lightAmplitude;
      s{3} = obj.stimulationPeriod;
      s{4} = obj.stimulationFrequency;
    end
    
    %% protocol routines
    function stim = createLedStimulus(obj, familyPulseNum)
      theAmplitude = obj.stimPattern{2}(familyPulseNum);
      thePeriod = obj.stimPattern{3}(familyPulseNum);
      
      stim = cell(1,2);
      
      gen = symphonyui.builtin.stimuli.SineGenerator();
      
      gen.preTime = obj.preTime;
      gen.stimTime = obj.stimTime;
      gen.tailTime = obj.tailTime;
      gen.amplitude = theAmplitude;
      gen.mean = obj.oscillationCenter;
      gen.phase = obj.phaseShift;
      gen.period = thePeriod;
      gen.sampleRate = obj.sampleRate;
      gen.units = obj.rig.getDevice(obj.led1).background.displayUnits;
      
      stim{1} = gen.generate();
      
      bg = symphonyui.builtin.stimuli.DirectCurrentGenerator();
      bg.offset = obj.led2Background;
      bg.sampleRate = obj.sampleRate;
      bg.units = obj.rig.getDevice(obj.led2).background.displayUnits;
      bg.time = 1e-3*obj.totalEpochTime;
      stim{2} = bg.generate();
      
    end
  end
  
end

