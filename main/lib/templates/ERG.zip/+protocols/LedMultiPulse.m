classdef LedMultiPulse < admin.core.LEDProtocol
  % LEDMULTIPULSE present simultaneous stimuli from multiple LEDs (DEV)
  
  methods
    
    function [tf, msg] = isValid(obj) %#ok<MANU>
      tf = false;
      msg = [];
    end
    
  end
end