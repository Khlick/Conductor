classdef LedRamp < admin.core.LEDProtocol
  %% Stimulus Controls
  properties
    rampMinimum = 0 % Minimum Voltage (V)
    rampMaximum = 1 % Maximum Voltage (V), multiple values will create family.
    rampMean = 0  % Voltage (V) for LED for pre and post step (i.e. background, see preview)
  end
  %% Temporal Controls
  properties
    preTime = 200           % Ramp leading duration (ms).
    rampDelay = 0           % Delay (ms) after step to initiate ramp interval.
    rampHold  = 0           % Time (ms) for holding ramp maximum value
    stimTime = 1000         % Ramp duration (ms)
    tailTime = 200          % Ramp trailing duration (ms).
  end
  %% Repeating behavior
  properties
    asFamily = true       % As family (1:nFam,1:nFam...) or (1,1,1,2,2,2,3...) if false
  end
  properties (Dependent)
    totalEpochTime   % Calculated total recording length of each epoch
    numberInFamily   % Total number of pulses in each family (depends on length of rampMax).
  end
  %% Display Controls
  properties (Hidden)
    rampMaximumType
  end
  %% Override Methods
  methods
    
    function didSetRig(obj)
      didSetRig@admin.core.LEDProtocol(obj);
      
      obj.rampMaximumType = ...
        symphonyui.core.PropertyType('denserealdouble', 'matrix');
      % set monitor to true
      if isprop(obj,'monitorStimulus')
        obj.setProperty('monitorStimulus', true);
      end
    end
    
    function setProperty(obj, name, value)
      ledProps = cellfun( ...
        @(v)regexp(v,'^led[0-9]+(?=$)','match', 'once'),...
        properties(obj), ...
        'unif', 0 ...
        );
      switch name
        case {'rampMinimum','rampMaximum','rampMean'}
          % Get led1 max voltage
          maxV = obj.rig.getDevice(obj.led1).getResource('maximum');
          % truncate to maximum or less
          value(value > maxV) = maxV;
          value = unique(value((value <= maxV) & (value >= 0)),'stable');
          if strcmp(name,'rampMaximum')
            % if setting the family value
            setProperty@admin.core.LEDProtocol(obj, name, value);
            obj.setProperty('delayBetweenEpochs',obj.delayBetweenEpochs);
            return
          end
        case ledProps
          % user super's method to reassign devices to properties
          setProperty@admin.core.LEDProtocol(obj, name, value);
          % set the amplitudes explicitly to account for new led range.
          obj.setProperty('rampMaximum', obj.getProperty('rampMaximum'));
          obj.setProperty('monitorStimulus', obj.getProperty('monitorStimulus'));
          return
        case 'delayBetweenEpochs'
          if ~isscalar(value)
            nVal = numel(value);
            nFam = obj.numberInFamily;
            if nVal > nFam
              value((nFam+1):end) = [];
            elseif nVal < nFam
              value(end + (1:(nFam-nVal))) = value(end);
            end
          end
      end
      setProperty@admin.core.LEDProtocol(obj, name, value);
    end
    
    function p = getPreview(obj, panel)
      p = symphonyui.builtin.previews.StimuliPreview(panel, ...
        @()createPreviewStimuli(obj));
      function s = createPreviewStimuli(obj)
        s = cell(1, obj.numberInFamily);
        for i = 1:numel(s)
          s{i} = obj.createStimuli(i);
        end
      end
    end
    
    function prepareRun(obj)
      prepareRun@admin.core.LEDProtocol(obj);
      
      hAmp = obj.rig.getDevice(obj.amp);
      hLed = obj.rig.getDevice(obj.led1);
      cm = admin.utils.getColorShades(1,obj.numberInFamily,true);
      cm = permute(cm,[3,2,1]);% using single shades so squeeze into 2 dims
      
      if obj.monitorStimulus
        obj.showFigure('admin.figures.MeanResponse', ...
          hLed, ...
          'instanceId', 'Led_Monitor', ...
          'colormapping', cm, ...
          'showEach', true, ...
          'groupBy', {'stimulusAmplitude'} ...
          );
      end
      
      obj.showFigure('admin.figures.Response', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'sweepColor', cm(1,:) ...
        );
      obj.showFigure('admin.figures.MeanResponse', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'colormapping', cm, ...
        'showEach', true, ...
        'groupBy', {'stimulusAmplitude'} ...
        );
      
    end
    
    function prepareEpoch(obj, epoch)
      prepareEpoch@admin.core.LEDProtocol(obj, epoch);
      
      % determine which pulse.
      if obj.asFamily
        pulseNum = mod(obj.numEpochsPrepared - 1, obj.numberInFamily) + 1;
      else
        fam = admin.utils.rep(1:obj.numberInFamily,1,obj.numberOfAverages);
        pulseNum = fam(obj.numEpochsPrepared);
      end
      
      epoch.addParameter('stimulusAmplitude', ...
        obj.rampMaximum(pulseNum) ...
        );
      
      epoch.addStimulus(obj.rig.getDevice(obj.led1), obj.createStimuli(pulseNum));
      epoch.addResponse(obj.rig.getDevice(obj.amp));
    end
    
    function completeEpoch(obj,epoch)
      completeEpoch@admin.core.LEDProtocol(obj,epoch);
    end
    
    function completeRun(obj)
      completeRun@admin.core.LEDProtocol(obj);
    end
    
    function prepareInterval(obj, interval)
      prepareInterval@admin.core.LEDProtocol(obj, interval);
      
      if isscalar(obj.delayBetweenEpochs)
        delayDuration = obj.delayBetweenEpochs * 1e-3;
      else
        if obj.asFamily
          pulseNum = mod(obj.numIntervalsPrepared - 1, obj.numberInFamily) + 1;
        else
          fam = admin.utils.rep(1:obj.numberInFamily,1,obj.numberOfAverages);
          pulseNum = fam(obj.numIntervalsPrepared);
        end
        delayDuration = obj.delayBetweenEpochs(pulseNum) * 1e-3;
      end
      
      device = obj.rig.getDevice(obj.led1);
      interval.addDirectCurrentStimulus( ...
        device, ...
        device.background, ...
        delayDuration, ...
        obj.sampleRate ...
        );
    end
    
    function tf = shouldContinuePreparingEpochs(obj)
      tf = obj.numEpochsPrepared < obj.numberOfAverages*obj.numberInFamily;
    end
    
    function tf = shouldContinueRun(obj)
      tf = obj.numEpochsCompleted < obj.numberOfAverages*obj.numberInFamily;
    end
    
  end
  
  %% Helper Methods
  methods
    %% get/set
    function t = get.totalEpochTime(obj)
      t = sum([obj.preTime,obj.rampDelay,obj.stimTime,obj.rampHold,obj.tailTime]);
    end
    
    function n = get.numberInFamily(obj)
      n = length(obj.rampMaximum);
    end
    
    %% protocol routines
    function stimSum = createStimuli(obj,stimNum)
      currentMax = obj.rampMaximum(stimNum);
      
      stim = cell(1,3);
      
      %determine led range
      device = obj.rig.getDevice(obj.led1);
      % Calculate the ramp amplitude from low-high
      stimAmplitude = diff([obj.rampMinimum,currentMax]);
      bgUnits = device.background.displayUnits;
      % First generate Ramp
      rmp = symphonyui.builtin.stimuli.RampGenerator();
      
      rmp.preTime = obj.preTime + obj.rampDelay;
      rmp.stimTime = obj.stimTime;
      rmp.tailTime = obj.tailTime + obj.rampHold;
      rmp.amplitude = stimAmplitude;
      rmp.mean = 0;
      rmp.sampleRate = obj.sampleRate;
      rmp.units = bgUnits;
      
      stim{1} = rmp.generate(); %ramp
      
      % then generate before and after pulse
      pls = symphonyui.builtin.stimuli.PulseGenerator();
      
      pls.preTime = obj.preTime;
      pls.stimTime = obj.stimTime + obj.rampDelay + obj.rampHold;
      pls.tailTime = obj.tailTime;
      pls.amplitude = obj.rampMinimum - obj.rampMean;
      pls.mean = obj.rampMean;
      pls.sampleRate = obj.sampleRate;
      pls.units = bgUnits;
      
      stim{2} = pls.generate(); %step
      
      % generate the holding pulse
      %
      pHold = symphonyui.builtin.stimuli.PulseGenerator();
      
      pHold.preTime = obj.preTime + obj.rampDelay + obj.stimTime;
      pHold.stimTime = obj.rampHold;
      pHold.tailTime = obj.tailTime;
      pHold.amplitude = stimAmplitude;
      pHold.mean = 0;
      pHold.sampleRate = obj.sampleRate;
      pHold.units = bgUnits;
      
      stim{3} = pHold.generate(); %step
      
      % Add the three stims together
      sSum = symphonyui.builtin.stimuli.SumGenerator();
      
      sSum.stimuli = stim;
      stimSum = sSum.generate();
    end
  end
  
end

