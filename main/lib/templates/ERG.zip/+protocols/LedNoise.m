classdef LedNoise < admin.core.LEDProtocol
  %% LED Controls
  
  properties
    monitorBackground = true % Set to true to record background LED and display.
    noiseMode            % Generator noise type
    noiseContrast = 0.8  % Contrast (SD) of the noise amplitude.
    noiseCenter = 1       % Center (V) of the noise stimulus.
    noiseBandwidth = 20   % Frequency (Hz) of the noise frequency bands (1 or 2 values depending on noise type).
    invertStimulus = false % should the noise presentation be inverted (i.e. flipped vertically)
    randomizeNoiseFamily = false % If a noise family given, false will reproduce the noise with varied contrast/centers
    resetNoiseRandomization = false % Set as true to reset the noise presentation randomization (it will automatically reset to false once applied).
    noiseSeed = 0 % the initial noise seed value.
  end
  
  %% Temporal Controls
  
  properties
    preTime = 0   % Leadin duration prior to stimulus (ms) (at led1 background)
    stimDelay = 250       % Duration (ms) to wait at noiseCenter(i) BEFORE stim, ie step duration
    stimTime = 3000 % Stim duration (ms) for noise presentation only (does not include delay or follow)
    stimFollowDelay = 250 % Duration (ms) to wait at noiseCenter AFTER stim
    tailTime = 0  % Leadout duration after stimulus end (ms) (at led1 background)
  end
  
  properties (Dependent)
    totalEpochDuration % Total epoch duration (ms)
  end
  %% Repeating behavior
  properties
    asFamily = true
  end
  properties (Dependent)
    numberInFamily   % Total number of pulses in each family.
  end
  
  %% Display Controls
  
  properties (Hidden)
    asFamilyType
    noiseCenterType
    noiseContrastType
    noiseBandwidthType
    noiseModeType
  end
  
  %% Helper Properties
  
  properties (Dependent, Hidden)
    stimPattern
    seeds
  end
  
  %% Override methods
  methods
    
    function didSetRig(obj)
      import symphonyui.core.PropertyType;
      
      didSetRig@admin.core.LEDProtocol(obj);
      
      obj.noiseCenterType = PropertyType('denserealdouble','matrix');
      obj.noiseContrastType = PropertyType('denserealdouble','matrix');
      obj.noiseBandwidthType = PropertyType('denserealdouble','matrix');
      noiseTypes = admin.stimuli.NoiseGenerator.allowableTypes();
      obj.noiseMode = noiseTypes{1};
      obj.noiseModeType = PropertyType('char', 'row', noiseTypes);
      obj.asFamilyType = PropertyType('logical','scalar');
      % set monitor to true
      if isprop(obj,'monitorStimulus')
        obj.setProperty('monitorStimulus', true);
      end
    end
    
    function setProperty(obj,name,value)
      longParams = {'noiseCenter','noiseContrast'};
      switch name
        case longParams
          % set this parameter
          setProperty@admin.core.LEDProtocol(obj, name, value);
          % set the length of all other length-dependent parameters based on the one
          % being set. If we need to expand, just copy the last element.
          lA = length(value);
          for Par = longParams(~ismember(longParams,name))
            param = Par{:};
            lB = length(obj.(param));
            if lA > lB
              otherVals = obj.(param);
              otherVals(end:end+(lA-lB)) = obj.(param)(end);
              setProperty@admin.core.LEDProtocol(obj, ...
                param, ...
                otherVals ...
                );
            elseif lA < lB
              setProperty@admin.core.LEDProtocol(obj, ...
                param, ...
                obj.(param)(1:lA) ...
                );
            end
          end
          % set epoch delay length
          obj.setProperty('delayBetweenEpochs',obj.delayBetweenEpochs);
          return
        case 'noiseBandwith'
          if contains(obj.noiseMode,'Band')
            % require nx2 matrix
            if isvector(value) && numel(value) ~=2
              value = [value(:),value(:)+1];
            elseif size(value,2) ~= 2
              if size(value,1) == 2
                value = value';
              else
                value = value(:,1:2);
              end
            end
            % now we should be Nx2, validate N
            lB = length(obj.noiseCenter);
            lA = size(value,1); %input
            
            if lA > lB
              % if input  > existing, append to noise center using local set method so
              % that it updates other long params.
              otherVals = obj.noiseCenter;
              otherVals(end:(end+(lA-lB))) = ...
                admin.utils.rep( ...
                otherVals(end), ...
                lA-lB+1, ...
                'dims', {[],1} ...
                );
              obj.setProperty( ...
                'noiseCenter', ...
                otherVals ...
                );
            elseif lA < lB
              % in input < existing, truncate existing (noise center) using local set
              % method so that it updates other length-depending params.
              obj.setProperty( ...
                'nosieCenter', ...
                obj.noiseCenter(1:lA) ...
                );
            end
          else
            value = value(:);
            % now we should be Nx2, validate N
            lB = length(obj.noiseCenter);
            lA = length(value); %input
            
            if lA > lB
              % if input  > existing, append to noise center using local set method so
              % that it updates other long params.
              otherVals = obj.noiseCenter;
              otherVals(end:(end+(lA-lB))) = ...
                admin.utils.rep( ...
                otherVals(end), ...
                lA-lB+1, ...
                'dims', {[],1} ...
                );
              obj.setProperty( ...
                'noiseCenter', ...
                otherVals ...
                );
            elseif lA < lB
              % in input < existing, truncate existing (noise center) using local set
              % method so that it updates other length-depending params.
              obj.setProperty( ...
                'nosieCenter', ...
                obj.noiseCenter(1:lA) ...
                );
            end
          end
        case 'noiseMode'
          % force the mode update and then update the bandwidth
          setProperty@admin.core.LEDProtocol(obj, name, value);
          obj.setProperty('noiseBandwith',obj.noiseBandwidth);
          return
        case 'delayBetweenEpochs'
          if ~isscalar(value)
            nVal = numel(value);
            nFam = obj.numberInFamily;
            if nVal > nFam
              value((nFam+1):end) = [];
            elseif nVal < nFam
              value(end + (1:(nFam-nVal))) = value(end);
            end
          end
      end
      % now set using super's method
      setProperty@admin.core.LEDProtocol(obj, name, value);
    end
    
    function p = getPreview(obj,panel)
      p = admin.figures.stimPreview(panel, ...
        @()createPreviewStimuli(obj));
      function s = createPreviewStimuli(obj)
        s = arrayfun( ...
          @(x) obj.createLedStimulus(x), ...
          1:obj.numberInFamily, ...
          'unif', 0 ...
          );
        s = cat(1, s{:})';
      end
    end
    
    function prepareRun(obj)
      prepareRun@admin.core.LEDProtocol(obj);
      
      hAmp = obj.rig.getDevice(obj.amp);
      hLed = obj.rig.getDevice(obj.led1);
      hLed2 = obj.rig.getDevice(obj.led2);
      cm = admin.utils.getColorShades(1,obj.numberInFamily,true);
      cm = permute(cm,[3,2,1]);% using single shades so squeeze into 2 dims
      
      if obj.monitorStimulus
        obj.showFigure('admin.figures.MeanResponse', ...
          hLed, ...
          'instanceId', 'Led_Monitor', ...
          'colormapping', cm, ...
          'showEach', true, ...
          'groupBy', {'stimID'} ...
          );
      end
      if obj.monitorBackground
        obj.showFigure('admin.figures.MeanResponse', ...
          hLed2, ...
          'instanceId', 'Led_Monitor_2', ...
          'colormapping', cm, ...
          'showEach', true, ...
          'groupBy', {'stimID'} ...
          );
      end
      
      obj.showFigure('admin.figures.Response', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'sweepColor', cm(1,:) ...
        );
      obj.showFigure('admin.figures.MeanResponse', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'colormapping', cm, ...
        'showEach', true, ...
        'groupBy', {'stimID'} ...
        );
      
    end
    
    function prepareEpoch(obj, epoch)
      prepareEpoch@admin.core.LEDProtocol(obj, epoch);
      hAmp = obj.rig.getDevice(obj.amp);
      hLed = obj.rig.getDevice(obj.led1);
      hLed2 = obj.rig.getDevice(obj.led2);
      % determine which pulse.
      if obj.asFamily
        fNum = mod(obj.numEpochsPrepared - 1, obj.numberInFamily) + 1;
      else
        fam = admin.utils.rep(1:obj.numberInFamily,1,obj.numberOfAverages);
        fNum = fam(obj.numEpochsPrepared);
      end
      
      stim = obj.createLedStimulus(fNum);
      epoch.addParameter('stimID', ...
        sprintf( ...
        '%s_center:%0.3fV_contrast:%0.3f_freq:%0.3f_seed:%d', ...
        obj.led1, ...
        obj.stimPattern.center(fNum), ...
        obj.stimPattern.contrast(fNum), ...
        obj.stimPattern.frequency(fNum), ...
        obj.stimPattern.seed(fNum) ...
        ) ...
        );
      
      epoch.addStimulus(hLed, stim{1});
      epoch.addResponse(hAmp);
      if obj.monitorBackground
        epoch.addResponse(hLed2);
      end
    end
    
    function prepareInterval(obj, interval)
      prepareInterval@admin.core.LEDProtocol(obj, interval);
      
      if isscalar(obj.delayBetweenEpochs)
        delayDuration = obj.delayBetweenEpochs * 1e-3;
      else
        if obj.asFamily
          pulseNum = mod(obj.numIntervalsPrepared - 1, obj.numberInFamily) + 1;
        else
          fam = admin.utils.rep(1:obj.numberInFamily,1,obj.numberOfAverages);
          pulseNum = fam(obj.numIntervalsPrepared);
        end
        delayDuration = obj.delayBetweenEpochs(pulseNum) * 1e-3;
      end
      
      device = obj.rig.getDevice(obj.led1);
      interval.addDirectCurrentStimulus( ...
        device, ...
        device.background, ...
        delayDuration, ...
        obj.sampleRate ...
        );
    end
    
    function tf = shouldContinuePreparingEpochs(obj)
      tf = obj.numEpochsPrepared < obj.numberOfAverages*obj.numberInFamily;
    end
    
    function tf = shouldContinueRun(obj)
      tf = obj.numEpochsCompleted < obj.numberOfAverages*obj.numberInFamily;
    end
    
  end
  
  %% Helper Methods
  methods
    %% set/get
    function t = get.totalEpochDuration(obj)
      t = (...
        obj.preTime + ...
        obj.stimTime + ...
        obj.stimDelay + ...
        obj.stimFollowDelay + ...
        obj.tailTime ...
        );
    end
    
    function s = get.seeds(obj)
      persistent newOrder
      if isempty(newOrder)
        newOrder = admin.utils.rep(obj.noiseSeed,obj.numberInFamily,1,'dim',{1,[]});
      elseif length(newOrder) > obj.numberInFamily
        newOrder = newOrder(1:obj.numberInFamily);
      elseif length(newOrder) < obj.numberInFamily
        difP = obj.numberInFamily - length(newOrder);
        newOrder = admin.utils.rep( newOrder, ...
          1, ...
          [ones(1,length(newOrder)-1),difP+1] ...
          );
      end
      if ~obj.randomizeNoiseFamily  && (obj.resetNoiseRandomization || any(diff(newOrder)))
        newOrder = admin.utils.rep(0,obj.numberInFamily,1,'dim',{1,[]});
      elseif obj.randomizeNoiseFamily && (obj.resetNoiseRandomization || ~all(diff(newOrder)))
        newOrder = randperm(obj.numberInFamily);
      end
      s = newOrder;
    end
    
    function p = get.numberInFamily(obj)
      p = max( ...
        [length(obj.noiseCenter),length(obj.noiseContrast)] ...
        );
    end
    
    function s = get.stimPattern(obj)
      s = struct();
      %amplitude
      s.contrast = obj.noiseContrast;
      %center
      s.center = obj.noiseCenter;
      %frequency
      s.frequency = obj.noiseBandwidth;
      %seed
      s.seed = obj.seeds;
    end
    
    %% protocol routines
    function stim = createLedStimulus(obj, fNum)
      
      stim = cell(1,1);
      %chirp
      ledDevice = obj.rig.getDevice(obj.led1);
      gen = admin.stimuli.NoiseGenerator();
      gen.type= obj.noiseMode; % noise type
      gen.preTime= obj.preTime;% Leading duration (ms)
      gen.stimTime= obj.stimTime;% noise wave duration (ms)
      gen.tailTime= obj.tailTime;% Trailing duration (ms)
      gen.stimDelay= obj.stimDelay;% Leadin time at oscillation center
      gen.stimFollow= obj.stimFollowDelay;% Trailing time at oscillation center
      gen.contrast= obj.stimPattern.contrast(fNum);% noise deviation (units)
      gen.center= obj.stimPattern.center(fNum);% oscillation center
      gen.background= ledDevice.background.quantity;
      gen.filtFreq= obj.stimPattern.frequency;% cutoff (if 1, or range if 2)
      gen.filtOrder= 11;
      gen.setSeed= obj.stimPattern.seed(fNum);% seed
      gen.outputLimits = [ ...
        0, ...
        ledDevice.getResource('maximum') ...
        ];
      gen.invert = obj.invertStimulus;
      gen.sampleRate= obj.sampleRate;% Sample rate of generated stimulus (Hz)
      gen.units= ledDevice.background.displayUnits;% Units of generated stimulus
      gen.addToBackground = ~obj.ignoreBackgroundInput;
      
      stim{1} = gen.generate();
    end
    
  end
end