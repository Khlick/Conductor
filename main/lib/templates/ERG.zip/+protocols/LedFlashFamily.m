classdef LedFlashFamily < admin.core.LEDProtocol
  % LEDFLASHFAMILY Record a flash family from supplying voltages to stimulus LED
  % Amplifier is passive.
  
  %% LED Controls
  properties
    % GENERATEFAMILY - Generate flash family by doubling the STIMAMPLITUDES. If
    % true, STIMAMPLITUDES will be set to a scalar value.
    generateFamily = false % Generate family by doubling stimAmplitude (forces scalar)
    stimAmplitudes = 0.015 % First pulse amplitude (V) *scalar | matrix*
  end
  %% Temporal Controls
  properties
    preTime = 200                % Leadin duration prior to stimulus (ms) *scalar*
    stimTime = 20                % Stim duration for LED pulse/step *matrix*
    tailTime = 1380              % Leadout duration after stimulus end (ms) *matrix*
  end
  properties (Dependent)
    totalEpochTime               % Total epoch duration (ms)
  end
  %% Repeating behavior
  properties
    % ASFAMILY - Changes the ordering of the epochs. A value of false will cause
    % each flash to repeat NUMBEROFAVERAGES times before moving to the next.
    asFamily = true
    numberInFamily = uint16(1)   % Number of pulses in family
  end
  %% Display Controls
  properties (Hidden)
    stimAmplitudesType
    stimTimeType
    tailTimeType
    numberInFamilyType
  end
  %% Other Properties
  properties (Dependent)
    stimValues % Voltages applied to Led1
  end
  %% Override Methods
  methods
    function didSetRig(obj)
      import symphonyui.core.PropertyType;
      % call the superclass method
      didSetRig@admin.core.LEDProtocol(obj);
      % set types
      obj.numberInFamilyType = PropertyType('uint16', 'scalar',[1,Inf]);
      obj.stimTimeType = PropertyType('denserealdouble','row');
      obj.tailTimeType = PropertyType('denserealdouble','row');
      obj.stimAmplitudesType = PropertyType('denserealdouble','row');
    end
    
    function setProperty(obj, name, value)
      switch name
        case 'generateFamily'
          if value
            setProperty@admin.core.LEDProtocol(obj,'stimAmplitudes',obj.stimAmplitudes(1));
          else
            setProperty@admin.core.LEDProtocol(obj,'stimAmplitudes',obj.stimValues);
          end
        case 'stimAmplitudes'
          if obj.generateFamily && ~isscalar(value)
            value = value(1);
          elseif ~isscalar(value)
            % Not generating family and value is not scalar, update the flashes
            % in family property
            n = numel(value);
            setProperty@admin.core.LEDProtocol(obj,'numberInFamily',uint16(n));
          end
          % set the length of the other parameters
          for prop = ["tailTime","stimTime","delayBetweenEpochs"]
            pval = obj.getProperty(char(prop));
            obj.setProperty(char(prop),pval);
          end
        case 'numberInFamily'
          if ~obj.getProperty('generateFamily')
            % can't change flash count when gen family is false
            value = numel(obj.stimAmplitudes);
          end
          % set the value so that we can use it in setting the lengths of the
          % tail and stim times
          setProperty@admin.core.LEDProtocol(obj, name, uint16(value));
          % use the setproperty method for stim and tail times to automatically
          % adjust their lengths
          for prop = ["tailTime","stimTime","delayBetweenEpochs"]
            pval = obj.getProperty(char(prop));
            obj.setProperty(char(prop),pval);
          end
          % we have already set the value, we can return from here
          return
        case {'stimTime','tailTime','delayBetweenEpochs'}
          n = obj.numberInFamily;
          nval = numel(value);
          if n > nval
            value(end+(1:(n-nval))) = value(end);
          elseif n < nval
            value((n+1):end) = [];
          end
      end
      
      % finally, set the property in the superclass
      setProperty@admin.core.LEDProtocol(obj, name, value);
    end
    
    function p = getPreview(obj, panel)
      p = symphonyui.builtin.previews.StimuliPreview(panel, ...
        @()createPreviewStimuli(obj));
      function s = createPreviewStimuli(obj)
        s = cell(1, obj.numberInFamily);
        for i = 1:numel(s)
          s{i} = obj.createLedStimulus(i);
        end
      end
    end
    
    function prepareRun(obj)
      prepareRun@admin.core.LEDProtocol(obj);
      
      hAmp = obj.rig.getDevice(obj.amp);
      cm = admin.utils.getColorShades(1,obj.numberInFamily,true);
      cm = permute(cm,[3,2,1]);% using single shades so squeeze into 2 dims
      
      obj.showFigure('admin.figures.Response', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'sweepColor', cm(1,:) ...
        );
      obj.showFigure('admin.figures.MeanResponse', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'colormapping', cm, ...
        'showEach', true, ...
        'groupBy', {'lightAmplitude', 'stimDuration'} ...
        );
      if obj.monitorStimulus
        obj.showFigure('admin.figures.MeanResponse', ...
          obj.rig.getDevice(obj.led1), ...
          'instanceId', 'Led_Monitor', ...
          'colormapping', cm, ...
          'showEach', true, ...
          'groupBy', {'lightAmplitude', 'stimDuration'} ...
          );
      end
      if obj.monitorBackground
        obj.showFigure('admin.figures.MeanResponse', ...
          obj.rig.getDevice(obj.led2), ...
          'instanceId', 'Led_Monitor_2', ...
          'colormapping', cm, ...
          'showEach', true, ...
          'groupBy', {'lightAmplitude', 'stimDuration'} ...
          );
      end
    end
    
    function prepareEpoch(obj, epoch)
      prepareEpoch@admin.core.LEDProtocol(obj, epoch);
      
      if obj.asFamily
        pulseNum = mod(obj.numEpochsPrepared - 1, obj.numberInFamily) + 1;
      else
        % create a vector of 1:numberInFamily each element repeated numAverages
        Indices = admin.utils.rep( ...
          (1:obj.numberInFamily)', ...
          1, ...
          obj.numberOfAverages ...
          );
        % pulsenum is the current position in the indices vector
        pulseNum = Indices(obj.numEpochsPrepared);
      end
      
      stim = obj.createLedStimulus(pulseNum);
      stimProps = stim.parameters;
      
      epoch.addParameter('lightAmplitude', stimProps('amplitude'));
      epoch.addParameter('stimDuration', stimProps('stimTime'));
      
      lDevice = obj.rig.getDevice(obj.led1);
      epoch.addStimulus(lDevice, stim);
      epoch.addResponse(obj.rig.getDevice(obj.amp));
    end
    
    function prepareInterval(obj, interval)
      prepareInterval@admin.core.LEDProtocol(obj, interval);
      if obj.asFamily
        pulseNum = mod(obj.numEpochsPrepared - 1, obj.numberInFamily) + 1;
      else
        % create a vector of 1:numberInFamily each element repeated numAverages
        Indices = admin.utils.rep( ...
          (1:obj.numberInFamily)', ...
          1, ...
          obj.numberOfAverages ...
          );
        % pulsenum is the current position in the indices vector
        pulseNum = Indices(obj.numEpochsPrepared);
      end
      % ensure the led background light persists through epoch intervals (does
      % this cause a double bg value? test
      device = obj.rig.getDevice(obj.led1);
      interval.addDirectCurrentStimulus( ...
        device, ...
        device.background, ... 
        obj.delayBetweenEpochs(pulseNum) * 1e-3, ... % convert from ms to sec for dc stim
        obj.sampleRate ...
        );
    end
    
    function completeEpoch(obj,epoch)
      completeEpoch@admin.core.LEDProtocol(obj,epoch);
    end
    
    function completeRun(obj)
      completeRun@admin.core.LEDProtocol(obj);
    end
    
    function tf = shouldContinuePreparingEpochs(obj)
      tf = obj.numEpochsPrepared < obj.numberOfAverages * obj.numberInFamily;
    end
    
    function tf = shouldContinueRun(obj)
      tf = obj.numEpochsCompleted < obj.numberOfAverages * obj.numberInFamily;
    end
    
  end
  %% Helper Methods
  methods
    %% set/get
    function t = get.totalEpochTime(obj)
      t = obj.tailTime + obj.preTime + obj.stimTime;
    end
    
    
    function v = get.stimValues(obj)
      % generate a value either of supplied amplitudes or by doubles depending
      % on whether generateFamily is 
      n = obj.numberInFamily;
      if obj.generateFamily
        v = obj.stimAmplitudes(1) * 2.^(double(1:n) - 1);
      else
        n = min([n,numel(obj.stimAmplitudes)]);
        v = obj.stimAmplitudes(1:n);
      end
    end
    
    %% Custom Routines
    function stim = createLedStimulus(obj, pulseNum)
      persistent LED;
      if isempty(LED)
        LED = obj.rig.getDevice(obj.led1);
      elseif ~isempty(LED) && ~isequal(LED.name,obj.led1)
        LED = obj.rig.getDevice(obj.led1);
      end
      
      lightAmplitude = obj.stimValues(pulseNum);
      
      
      gen = symphonyui.builtin.stimuli.PulseGenerator();
      
      gen.preTime = obj.preTime;
      gen.stimTime = obj.stimTime(pulseNum);
      gen.tailTime = obj.tailTime(pulseNum);
      gen.amplitude = lightAmplitude;
      gen.mean = LED.background.quantity;
      gen.sampleRate = obj.sampleRate;
      gen.units = LED.background.displayUnits;
      
      stim = gen.generate();
    end
    
  end
end

