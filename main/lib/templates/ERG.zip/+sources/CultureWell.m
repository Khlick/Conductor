classdef CultureWell < symphonyui.core.persistent.descriptions.SourceDescription
  
  methods
    function obj = CultureWell()
      import symphonyui.core.PropertyType;
      
      obj.addProperty('wellNumber', 0, ...
        'description', 'Which well number?');
      
      obj.addProperty('wellId', '', ...
        'description', 'What is the ID of this well?');
      
      obj.addProperty('wellComment', '', ...
        'description', 'Add a comment on the well quality.' ...
        );
      
      
      % locate the parent root of this source
      pkgRoot = admin.utils.getOpenSetupRoot();
      if isempty(pkgRoot), return; end
      
      % set the allowable parent if the root was found
      obj.addAllowableParentType(sprintf('%s.sources.CellCulture',pkgRoot));
    end
  end
  
end

