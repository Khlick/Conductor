classdef Prep < symphonyui.core.persistent.descriptions.SourceDescription
  
  methods
    
    function obj = Prep()
      import symphonyui.core.*;
      
      obj.addProperty('prepNumber', 0, ...
        'description', 'Which number preparation is this?');
      
      obj.addProperty('prepType', 'NA', ...
        'type', ...
          PropertyType('char', 'row', ...
            {'NA', 'Dorsal', 'Ventral','Medial','Lateral', 'Whole', 'Eyecup', '...'}), ...
        'description', 'What part of the eye was this prep taken.' ...
        );
      
      obj.addProperty('prepComment', '', ...
        'description', 'Add a comment on the preparation quality.' ...
        );
      
      % locate the parent root of this source
      pkgRoot = admin.utils.getOpenSetupRoot();
      if isempty(pkgRoot), return; end
      
      % set the allowable parent if the root was found
      obj.addAllowableParentType(sprintf('%s.sources.Retina',pkgRoot));
    end
    
  end
end

