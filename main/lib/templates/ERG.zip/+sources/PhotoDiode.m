classdef PhotoDiode < symphonyui.core.persistent.descriptions.SourceDescription
  
  methods
    function obj = PhotoDiode()
      import symphonyui.core.*;
      
      obj.addProperty('calibrationDescription', '', ...
        'description', 'Description about the photodiode in use.', ...
        'category', 'Calibration Parameters' ...
        );
      
    end
  end
  
end

