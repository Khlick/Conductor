classdef Retina < symphonyui.core.persistent.descriptions.SourceDescription
  
  methods
    function obj = Retina()
      obj = obj@symphonyui.core.persistent.descriptions.SourceDescription();
      import symphonyui.core.*;
      
      obj.addProperty('Eye', 'NA', ...
        'type', ...
        PropertyType('char', 'row', ...
        {'NA', 'Left', 'Right'}), ...
        'description', 'Which eye was used in this preparation?', ...
        'category', 'Experiment Parameters');
      
      obj.addProperty('experimentDescription', '', ...
        'description', 'Some small note about this retina slice', ...
        'category', 'Experiment Parameters');
      
      % locate the parent root of this source
      pkgRoot = admin.utils.getOpenSetupRoot();
      if isempty(pkgRoot)
        pkgRoot = []; %disallow nesting
      else
        pkgRoot = sprintf('%s.sources.Animal',pkgRoot);
      end
      
      obj.addAllowableParentType(pkgRoot);
    end
  end
  
end

