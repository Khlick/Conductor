classdef Slice < symphonyui.core.persistent.descriptions.SourceDescription
  
  methods
    
    function obj = Slice()
      import symphonyui.core.*;
      
      obj.addProperty('sliceNumber', 0, ...
        'description', 'Which slice from the block was used?');
      
      obj.addProperty('sliceComment', '', ...
        'description', 'Add a comment on the slice quality.' ...
        );
      
      % locate the parent root of this source
      pkgRoot = admin.utils.getOpenSetupRoot();
      if isempty(pkgRoot), return; end
      
      % set the allowable parent if the root was found
      obj.addAllowableParentType(sprintf('%s.sources.Retina',pkgRoot));
      
    end
    
  end
end

