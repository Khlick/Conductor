classdef LedChirp < admin.core.LEDProtocol
  %% LED Controls
  
  properties
    monitorBackground = true % Set to true to record background LED and display.
    chirpAmplitude = 0.8  % Peak-to-Peak amplitude of the chirp
    phaseShift = pi/2     % Phase angle to start sine (in radians; eg. pi/2)
    chirpCenter = 1.0     % Background intensity (V)
    frequencyInit = 0.0   % Starting Frequency of chirp (Hz)
    frequencyFinal = 20.0 % Frequency (Hz) chirp crosses at stimTime
    chirpMode = 'Linear'  % Frequency sweep method, Linear, Logarithmic or Quadratic
    %chirpQuadMode -  Direction of quadratic chirp specified as "concave" or
    %"convex". This setting only applies when chirpMode is "Quadratic".
    chirpQuadMode = 'concave'
    chirpIncreasing = true
    chirpSymmetry = 'Asymmetric'
  end
  
  %% Temporal Controls
  
  properties
    preTime = 200   % Leadin duration prior to stimulus (ms)
    stimDelay = 0       % Duration (ms) to wait at chirpCenter BEFORE stim, ie step duration
    stimTime = 2000 % Stim duration for Chirp only
    stimFollowDelay = 0 % Duration (ms) to wait at chirpCenter AFTER stim
    tailTime = 200  % Leadout duration after stimulus end (ms)
  end
  
  properties (Dependent)
    totalEpochTime % Total epoch duration (ms)
  end
  %% Repeating behavior
  properties (Dependent)
    numberInFamily   % Total number of pulses in each family.
  end
  
  %% Display Controls
  
  properties (Hidden)
    chirpModeType
    chirpQuadModeType
    chirpSymmetryType
    frequencyInitType
    frequencyFinalType
    phaseShiftType
    chirpCenterType
    chirpAmplitudeType
  end
  
  %% Helper Properties
  
  properties (Dependent, Hidden)
    stimPattern
  end
  
  %% Override methods
  methods
    
    function didSetRig(obj)
      import symphonyui.core.PropertyType;
      
      didSetRig@admin.core.LEDProtocol(obj);
      
      obj.chirpModeType = PropertyType( ...
        'char', 'row', ...
        {'Linear','Logarithmic','Quadratic'} ... % domain
        );
      obj.chirpQuadModeType = PropertyType( ...
        'char', 'row', ...
        {'concave','convex'} ... % domain
        );
      obj.chirpSymmetryType = PropertyType( ...
        'char', 'row', ...
        {'Asymmetric','Symmetric'} ... % domain
        );
      obj.frequencyInitType = PropertyType('denserealdouble','matrix');
      obj.frequencyFinalType = PropertyType('denserealdouble','matrix');
      obj.phaseShiftType = PropertyType('denserealdouble','matrix');
      obj.chirpCenterType = PropertyType('denserealdouble','matrix');
      obj.chirpAmplitudeType = PropertyType('denserealdouble','matrix');
      % set monitor to true
      if isprop(obj,'monitorStimulus')
        obj.setProperty('monitorStimulus', true);
      end
    end
    
    function setProperty(obj, name, value)
      longParams = { ...
        'frequencyInit', ...
        'frequencyFinal', ...
        'chirpCenter', ...
        'phaseShift', ...
        'chirpAmplitude' ...
        };
      switch name
        case longParams
          % alter length if invalid values
          if strcmp(name,'frequencyInit') && strcmp(obj.chirpMode,'Logarithmic')
            value(value < 1e-6) = 1e-6;
            value = unique(value,'stable');
          end
          lA = length(value);
          for Par = longParams(~ismember(longParams,name))
            param = Par{:};
            lB = length(obj.(param));
            if lA > lB
              otherVals = obj.(param);
              otherVals(end:end+(lA-lB)) = ...
                admin.utils.rep( ...
                obj.(param)(end), ...
                lA-lB+1, ...
                'dims', {1,[]} ...
                );
              setProperty@admin.core.LEDProtocol(obj, ...
                param, ...
                otherVals ...
                );
            elseif lA < lB
              setProperty@admin.core.LEDProtocol(obj, ...
                param, ...
                obj.(param)(1:lA) ...
                );
            end
          end
        case 'chirpMode'
          if strcmp(value,'Logarithmic')
            if any(obj.frequencyInit < 1e-6)
              % force truncation
              setProperty@admin.core.LEDProtocol(obj, name, value);
              obj.setProperty('frequencyInit',obj.frequencyInit);
              return
            end
          end
        case 'delayBetweenEpochs'
          if ~isscalar(value)
            nVal = numel(value);
            nFam = obj.numberInFamily;
            if nVal > nFam
              value((nFam+1):end) = [];
            elseif nVal < nFam
              value(end + (1:(nFam-nVal))) = value(end);
            end
          end
      end %end switch
      
      setProperty@admin.core.LEDProtocol(obj, name, value);
    end
    
    function p = getPreview(obj,panel)
      p = admin.figures.stimPreview(panel, ...
        @()createPreviewStimuli(obj));
      function s = createPreviewStimuli(obj)
        s = arrayfun(@(x)obj.createLedStimulus(x),...
          1:obj.numberInFamily, 'unif',0);
        s = cat(1, s{:})';
      end
    end
    
    function prepareRun(obj)
      prepareRun@admin.core.LEDProtocol(obj);
      
      hAmp = obj.rig.getDevice(obj.amp);
      hLed = obj.rig.getDevice(obj.led1);
      hLed2 = obj.rig.getDevice(obj.led2);
      cm = admin.utils.getColorShades(1,obj.numberInFamily,true);
      cm = permute(cm,[3,2,1]);% using single shades so squeeze into 2 dims
      
      if obj.monitorStimulus
        obj.showFigure('admin.figures.MeanResponse', ...
          hLed, ...
          'instanceId', 'Led_Monitor', ...
          'colormapping', cm, ...
          'showEach', true, ...
          'groupBy', {'chirpID'} ...
          );
      end
      if obj.monitorBackground
        obj.showFigure('admin.figures.MeanResponse', ...
          hLed2, ...
          'instanceId', 'Led_Monitor_2', ...
          'colormapping', cm, ...
          'showEach', true, ...
          'groupBy', {'chirpID'} ...
          );
      end
      
      obj.showFigure('admin.figures.Response', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'sweepColor', cm(1,:) ...
        );
      obj.showFigure('admin.figures.MeanResponse', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'colormapping', cm, ...
        'showEach', true, ...
        'groupBy', {'chirpID'} ...
        );
    end
    
    function prepareEpoch(obj, epoch)
      prepareEpoch@admin.core.LEDProtocol(obj, epoch);
      
      hAmp = obj.rig.getDevice(obj.amp);
      hLed1 = obj.rig.getDevice(obj.led1);
      hLed2 = obj.rig.getDevice(obj.led2);
      
      fNum = mod( ...
        obj.numEpochsPrepared - 1, obj.numberInFamily ...
        ) + 1;
      stim = obj.createLedStimulus(fNum);
      chirpRange = sprintf('%0.2g-%0.2gHz', ...
        obj.stimPattern.frequencies(fNum,1), ...
        obj.stimPattern.frequencies(fNum,2) ...
        );
      epoch.addParameter('chirpRange', ...
        chirpRange ...
        );
      epoch.addParameter('chirpID', ...
        sprintf( ...
        '%sa%0.3gc%0.2gp%0.3gR%s', ...
        obj.led1, ...
        obj.stimPattern.amplitudes(fNum), ...
        obj.stimPattern.centers(fNum), ...
        obj.stimPattern.phases(fNum), ...
        chirpRange ...
        ) ...
        );
      % superclass property monitorStimulus will automatically add a response to
      % obj.led1 if true. Here we add the stimuli and response to to obj.led2 if
      % it is present.
      epoch.addStimulus(hLed1, stim{1});
      epoch.addStimulus(hLed2, stim{2});
      epoch.addResponse(hAmp);
      if obj.monitorBackground
        epoch.addResponse(hLed2);
      end
    end
    
    function prepareInterval(obj, interval)
      prepareInterval@admin.core.LEDProtocol(obj, interval);
      
      if isscalar(obj.delayBetweenEpochs)
        delayDuration = obj.delayBetweenEpochs * 1e-3;
      else
        pulseNum = mod(obj.numIntervalsPrepared - 1, obj.numberInFamily) + 1;
        delayDuration = obj.delayBetweenEpochs(pulseNum) * 1e-3;
      end
      
      device = obj.rig.getDevice(obj.led1);
      interval.addDirectCurrentStimulus( ...
        device, ...
        device.background, ...
        delayDuration, ...
        obj.sampleRate ...
        );
    end
    
    function tf = shouldContinuePreparingEpochs(obj)
      tf = obj.numEpochsPrepared < obj.numberOfAverages*obj.numberInFamily;
    end
    
    function completeEpoch(obj,epoch)
      completeEpoch@admin.core.LEDProtocol(obj,epoch);
    end
    
    function tf = shouldContinueRun(obj)
      tf = obj.numEpochsCompleted < obj.numberOfAverages*obj.numberInFamily;
    end
    
    function completeRun(obj)
      import symphonyui.core.Measurement;
      % call the superclass method
      completeRun@admin.core.LEDProtocol(obj);
      % if persisting backgrounds, we need to set them as backgrounds now.
      if obj.persistLedBackground && ~obj.ignoreBackgroundInput
        p = properties(obj);
        % set LED backgrounds to 0 if present.
        pLED = [ ...
          p(cellfun(@(x)~isempty(regexpi(x,'^led\d+(?!Background$)', 'once')),p,'unif',1)),...
          p(cellfun(@(x)~isempty(regexpi(x,'^led\d+Background$', 'once')),p,'unif',1)) ...
          ];
        if ~isempty(p)
          for d = 1:size(pLED,1)
            dName = pLED{d,1};
            device = obj.rig.getDevice(obj.(dName));
            value = obj.(pLED{d,2});%bg
            device.background = Measurement(value,device.background.displayUnits);
            device.applyBackground();
          end
        end
      end
    end
    
    
    function [tf,msg] = isValid(obj)
      tf = isprop(obj,'led2');
      if ~tf
        msg = sprintf('%s requires at least 2 leds configured.',class(obj));
      else
        msg = '';
      end
    end
    
    
  end
  
  %% Helper Methods
  methods
    %% set/get
    function t = get.totalEpochTime(obj)
      t = (...
        obj.preTime + ...
        obj.stimTime + ...
        obj.stimDelay + ...
        obj.stimFollowDelay + ...
        obj.tailTime ...
        );
    end
    
    function p = get.numberInFamily(obj)
      p = length(obj.frequencyInit);
    end
    
    function s = get.stimPattern(obj)
      s = struct();
      %amplitude
      s.amplitudes = obj.chirpAmplitude;
      %center
      s.centers = obj.chirpCenter;
      %frequencies
      s.frequencies = [obj.frequencyInit(:),obj.frequencyFinal(:)];
      %phase
      s.phases = obj.phaseShift;
    end
    
    %% protocol routines
    function stim = createLedStimulus(obj, fNum)
      
      stim = cell(1,2);
      %chirp
      gen = admin.stimuli.ChirpGenerator();
      % static parameters
      gen.sampleRate= obj.sampleRate;% Sample rate of generated stimulus (Hz)
      gen.units= obj.rig.getDevice(obj.led1).background.displayUnits;% Units (V)
      gen.preTime= obj.preTime;% Leading duration (ms)
      gen.stimTime= obj.stimTime;% Sine wave duration (ms)
      gen.tailTime= obj.tailTime;% Trailing duration (ms)
      gen.stimDelay= obj.stimDelay;% Leadin time at oscillation center
      gen.followDelay= obj.stimFollowDelay;% Trailing time at oscillation center
      gen.isIncreasing= obj.chirpIncreasing; % set to false to reverse frequency
      gen.symmetric= strcmp(obj.chirpSymmetry,'Symmetric'); % symmetric around stimTime/2
      gen.quadMode= char(obj.chirpQuadMode);
      
      % dynamic parameters
      gen.amplitude= obj.stimPattern.amplitudes(fNum);% Chirp amplitude (units)
      gen.freqStart= obj.stimPattern.frequencies(fNum,1);% Initial frequency (Hz)
      gen.freqStop= obj.stimPattern.frequencies(fNum,2);% Final frequency (Hz)
      gen.phase= obj.stimPattern.phases(fNum);% Phase offset (radians)
      gen.center= obj.stimPattern.centers(fNum);% oscillation center
      
      % parameters that depend on other parameters being set first
      gen.method= char(obj.chirpMode);% "Linear", "Logarithmic" or "Quadratic"
      
      
      %background
      bg = symphonyui.builtin.stimuli.DirectCurrentGenerator();
      bg.offset = obj.led2Background;
      bg.sampleRate = obj.sampleRate;
      bg.units = obj.rig.getDevice(obj.led2).background.displayUnits;
      bg.time = 1e-3*obj.totalEpochTime;
      
      stim{1} = gen.generate();
      stim{2} = bg.generate();
      
    end
  end
end

