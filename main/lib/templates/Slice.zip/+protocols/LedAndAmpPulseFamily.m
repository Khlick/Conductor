classdef LedAndAmpPulseFamily < admin.core.LEDProtocol
  % LedAndAmpPulseFamily Record a step family while also providing light steps
  
  %% Stimulus Controls
  properties
    generateLedFamily = false % Generate family by doubling stimAmplitude (forces scalar)
    generatePulseFamily = false % Generate family by doubling pulseTime (forces scalar)
    stimAmplitudes = 0.015 % First pulse amplitude (V) *scalar | matrix*
    pulseDevice % Device which presents pulse family
    % PULSEAMPLITUDES - Will pulse from background value to this value for
    % pulseTime duration. Setting incompatible amplitude will result in error!
    pulseAmplitudes = 0 % Pulse amplitudes (V) *scalar | matrix*
  end
  %% Temporal Controls
  properties
    preTime = 200                % Leadin duration prior to stimulus (ms) *scalar*
    stimTime = 10                % Stim duration for LED stimulus *scalar | matrix*
    totalEpochTime = 1500        % Total epoch duration (ms)    
    pulseDelayTime = 0           % Duration to wait after preTime before pulse begins (ms)
    pulseTime = 30               % Stim duration for amp/digital stimulus *scalar | matrix*
  end
  properties (Dependent)
    tailTime              % Leadout duration after led stimulus end (ms) *matrix*
    pulseTailTime         % Leadout duration after amp/digital stimulus end (ms) *matrix*
  end
  %% Repeating behavior
  properties
    % ASFAMILY - Changes the ordering of the epochs. A value of false will cause
    % each flash to repeat NUMBEROFAVERAGES times before moving to the next.
    asFamily = true
    numberInFamily = uint16(1)   % Number of pulses in family
  end
  %% Display Controls
  properties (Hidden)
    pulseDeviceType
    stimAmplitudesType
    pulseAmplitudesType
    stimTimeType
    pulseTimeType
    numberInFamilyType
  end
  %% Other Properties
  properties (Dependent)
    stimValues % Voltages applied to Led1
    pulseValues % Voltages applied to pulseDevice
  end
  %% Core Methods
  methods
    
    function didSetRig(obj)
      import symphonyui.core.PropertyType;
      % call the superclass method
      didSetRig@admin.core.LEDProtocol(obj);
      % set types
      obj.numberInFamilyType = PropertyType('uint16', 'scalar',[1,Inf]);
      obj.stimTimeType = PropertyType('denserealdouble','row');
      obj.pulseTimeType = PropertyType('denserealdouble','row');
      obj.stimAmplitudesType = PropertyType('denserealdouble','row');
      obj.pulseAmplitudesType = PropertyType('denserealdouble','row');
      [obj.pulseDevice,obj.pulseDeviceType] = obj.createStimulusNamesProperty();
    end
    
    function setProperty(obj, name, value)
      % SETPROPERTY Error handling and property validation
      import admin.utils.showMessage
      switch name
        case 'numberInFamily'
          % make sure that if generateLedFamily is true, this value does not
          % exceed maximum
          if obj.generateLedFamily
            v = obj.stimAmplitudes(1) * 2.^(double(1:value) - 1);
            [tf,~] = obj.validateAmplitudes(obj.led1,v);
            if ~tf
              value = obj.getProperty('numberInFamily');
            end
          end
          % updates length of every input
          setProperty@admin.core.LEDProtocol(obj,name,uint16(value));
          % use the setproperty method for stim and tail times to automatically
          % adjust their lengths (for time vars)
          for prop = ["pulseTime","stimTime","delayBetweenEpochs","pulseAmplitudes"]
            pval = obj.getProperty(char(prop));
            obj.setProperty(char(prop),pval);
          end
          % we have already set the value, we can return from here
          return
        case 'generateLedFamily'
          if value
            setProperty@admin.core.LEDProtocol(obj,'stimAmplitudes',obj.stimAmplitudes(1));
          else
            setProperty@admin.core.LEDProtocol(obj,'stimAmplitudes',obj.stimValues);
          end
        case 'generatePulseFamily'
          if value
            setProperty@admin.core.LEDProtocol(obj,'pulseAmplitudes',obj.pulseAmplitudes(1));
          else
            setProperty@admin.core.LEDProtocol(obj,'pulseAmplitudes',obj.pulseValues);
          end
        case {'pulseTime','stimTime','delaybetweenEpochs'}
          % validate numel
          value = obj.validateLength(value);
        case 'stimAmplitudes'
          if obj.generateLedFamily && ~isscalar(value)
            showMessage( ...
              'Only the first value is used when "Generate LED Family" is checked.', ...
              'Warning', ...
              'button1', 'OK' ...
              );
            value = value(1);
          end
          % validate range
          [tf,msg] = obj.validateAmplitudes(obj.led1,value);
          if ~tf
            % show message warning
            showMessage(msg, 'Warning', 'button1', 'OK');
            led = obj.rig.getDevice(obj.led1);
            maxV = led.getResource('maximum');
            value(value > maxV) = [];
          end
          % validate numel
          n = numel(value);
          value = obj.validateLength(value);
          if (numel(value) ~= n) && ~obj.generateLedFamily
            showMessage( ...
              sprintf( ...
                'Can only enter (%d) values determined by "Number In Family".', ...
                obj.numberInFamily ...
                ), ...
              'Warning', ...
              'button1', 'OK' ...
              );
          end
        case 'pulseAmplitudes'
          if obj.generatePulseFamily && ~isscalar(value)
            showMessage( ...
              'Only the first value is used when "Generate Pulse Family" is checked.', ...
              'Warning', ...
              'button1', 'OK' ...
              );
            value = value(1);
          end
          % validate numel
          n = numel(value);
          value = obj.validateLength(value);
          if (numel(value) ~= n) && ~obj.generatePulseFamily
            showMessage( ...
              sprintf( ...
                'Can only enter (%d) values determined by "Number In Family".', ...
                obj.numberInFamily ...
                ), ...
              'Warning', ...
              'button1', 'OK' ...
              );
          end
        case 'led1'
          % if setting led1 and monitor is true, make sure we have an input stream.
          if obj.monitorStimulus
            device = obj.rig.getDevice(char(value));
            streams = device.getInputStreams();
            if isempty(streams)
              setProperty@admin.core.LEDProtocol(obj,'monitorStimulus',false);
              fprintf(2,'No input streams for %s (%s).\n',device.name,class(obj));
            end
          end
      end
      
      % finally, set the property in the superclass
      setProperty@admin.core.LEDProtocol(obj, name, value);
    end
    
    function p = getPreview(obj, panel)
      % GETPREVIEW Generates the stimulus preview on ui main presenter
      p = admin.figures.dualStimPreview(panel, ...
        @()createPreviewStimuli(obj));
      function s = createPreviewStimuli(obj)
        s = cell(2, obj.numberInFamily);
        for i = 1:obj.numberInFamily
            s{1,i} = obj.createLedStimulus(i);
            s{2,i} = obj.createPulseStimulus(i);
        end
      end
    end

    function prepareRun(obj)
      prepareRun@admin.core.LEDProtocol(obj);
      
      hAmp = obj.rig.getDevice(obj.amp);
      groupBy = {'lightAmplitude','stimDuration','pulseAmplitude','pulseDuration'};
      
      cm = admin.utils.getColorShades(1,obj.numberInFamily,true);
      cm = permute(cm,[3,2,1]);% using single shades so squeeze into 2 dims
      
      obj.showFigure('admin.figures.Response', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'sweepColor', cm(1,:) ...
        );
      obj.showFigure('admin.figures.MeanResponse', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'colormapping', cm, ...
        'showEach', true, ...
        'groupBy', groupBy ...
        );
      if obj.monitorStimulus
        obj.showFigure('admin.figures.MeanResponse', ...
          obj.rig.getDevice(obj.led1), ...
          'instanceId', 'Led_Monitor', ...
          'colormapping', cm, ...
          'showEach', true, ...
          'groupBy', groupBy ...
          );
      end
      if obj.monitorBackground
        obj.showFigure('admin.figures.MeanResponse', ...
          obj.rig.getDevice(obj.led2), ...
          'instanceId', 'Led_Background', ...
          'colormapping', cm, ...
          'showEach', true, ...
          'groupBy', groupBy ...
          );
      end
    end
    
    function prepareEpoch(obj, epoch)
      prepareEpoch@admin.core.LEDProtocol(obj, epoch);
      
      if obj.asFamily
        pulseNum = mod(obj.numEpochsPrepared - 1, obj.numberInFamily) + 1;
      else
        % create a vector of 1:numberInFamily each element repeated numAverages
        Indices = admin.utils.rep( ...
          (1:obj.numberInFamily)', ...
          1, ...
          obj.numberOfAverages ...
          );
        % pulsenum is the current position in the indices vector
        pulseNum = Indices(obj.numEpochsPrepared);
      end
      
      [lStim,lAmp,lDur,lTail] = obj.createLedStimulus(pulseNum);
      epoch.addParameter('lightAmplitude', lAmp);
      epoch.addParameter('stimDuration', lDur);
      epoch.addParameter('lightTail', lTail);
      
      [pStim,pAmp,pDur,pTail] = obj.createPulseStimulus(pulseNum);
      epoch.addParameter('pulseAmplitude', pAmp);
      epoch.addParameter('pulseDuration', pDur);
      epoch.addParameter('pulseTail', pTail);
      
      lDevice = obj.rig.getDevice(obj.led1);
      pDevice = obj.rig.getDevice(obj.pulseDevice);
      epoch.addStimulus(lDevice, lStim);
      epoch.addStimulus(pDevice, pStim);
      epoch.addResponse(obj.rig.getDevice(obj.amp));
    end
    
    function prepareInterval(obj, interval)
      prepareInterval@admin.core.LEDProtocol(obj, interval);
      if obj.asFamily
        pulseNum = mod(obj.numEpochsPrepared - 1, obj.numberInFamily) + 1;
      else
        % create a vector of 1:numberInFamily each element repeated numAverages
        Indices = admin.utils.rep( ...
          (1:obj.numberInFamily)', ...
          1, ...
          obj.numberOfAverages ...
          );
        % pulsenum is the current position in the indices vector
        pulseNum = Indices(obj.numEpochsPrepared);
      end
      % ensure the led background light persists through epoch intervals (does
      % this cause a double bg value? test
      if isscalar(obj.delayBetweenEpochs)
        delayTime = obj.delayBetweenEpochs;
      elseif numel(obj.delayBetweenEpochs) < pulseNum
        delayTime = obj.delayBetweenEpochs(end);
      else
        delayTime = obj.delayBetweenEpochs(pulseNum);
      end
      device = obj.rig.getDevice(obj.led1);
      interval.addDirectCurrentStimulus( ...
        device, ...
        device.background, ... 
        delayTime * 1e-3, ... % convert from ms to sec for dc stim
        obj.sampleRate ...
        );
    end
    
    function completeEpoch(obj,epoch)
      completeEpoch@admin.core.LEDProtocol(obj,epoch);
    end
    
    function completeRun(obj)
      completeRun@admin.core.LEDProtocol(obj);
    end
    
    function tf = shouldContinuePreparingEpochs(obj)
      tf = obj.numEpochsPrepared < obj.numberOfAverages * obj.numberInFamily;
    end
    
    function tf = shouldContinueRun(obj)
      tf = obj.numEpochsCompleted < obj.numberOfAverages * obj.numberInFamily;
    end
  end
  
  %% Custom Methods
  methods
    
    %%% Set/Get
    function t = get.tailTime(obj)
      adjTime = obj.preTime + obj.stimTime;
      if max(adjTime) > obj.totalEpochTime
        obj.setProperty( ...
          'totalEpochTime', ...
          obj.totalEpochTime + abs(obj.totalEpochTime - adjTime) ...
          );
      end
      t = obj.totalEpochTime - adjTime;
    end
    
    function t = get.pulseTailTime(obj)
      adjTime = obj.preTime + obj.pulseDelayTime + obj.pulseTime;
      if max(adjTime) > obj.totalEpochTime
        obj.setProperty( ...
          'totalEpochTime', ...
          obj.totalEpochTime + abs(obj.totalEpochTime - adjTime) ...
          );
        pause(0.001);
      end
      t = obj.totalEpochTime - adjTime;
    end
    
    function v = get.stimValues(obj)
      % generate a value either of supplied amplitudes or by doubles depending
      % on whether generateLedFamily is 
      n = obj.numberInFamily;
      if obj.generateLedFamily
        v = obj.stimAmplitudes(1) * 2.^(double(1:n) - 1);
      else
        n = min([n,numel(obj.stimAmplitudes)]);
        v = obj.stimAmplitudes(1:n);
      end
    end
    
    function v = get.pulseValues(obj)
      % generate a value either of supplied amplitudes or by doubles depending
      % on whether generatePulseFamily is 
      n = obj.numberInFamily;
      if obj.generatePulseFamily
        v = obj.pulseAmplitudes(1) * 2.^(double(1:n) - 1);
      else
        n = min([n,numel(obj.pulseAmplitudes)]);
        v = obj.pulseAmplitudes(1:n);
      end
    end
    
    %%% Stimulus Creation
    
    function varargout = createLedStimulus(obj,pulseNum)
      % CREATELEDSTIMULUS Generates LED stimulus amplitude relative to bg.
      persistent LED;
      if isempty(LED)
        LED = obj.rig.getDevice(obj.led1);
      elseif ~isempty(LED) && ~isequal(LED.name,obj.led1)
        LED = obj.rig.getDevice(obj.led1);
      end
      lightAmplitude = obj.stimValues(pulseNum);
      lightDuration = obj.stimTime(pulseNum);
      lightTail = obj.tailTime(pulseNum);

      gen = symphonyui.builtin.stimuli.PulseGenerator();

      gen.preTime = obj.preTime;
      gen.stimTime = lightDuration;
      gen.tailTime = lightTail;
      gen.amplitude = lightAmplitude;
      gen.mean = LED.background.quantity;
      gen.sampleRate = obj.sampleRate;
      gen.units = LED.background.displayUnits;

      stim = gen.generate();
      
      varargout{1} = stim;
      if nargout > 1
        varargout{2} = lightAmplitude;
      end
      if nargout > 2
        varargout{3} = lightDuration;
      end
      if nargout > 3
        varargout{4} = lightTail;
      end
    end
    
    function varargout = createPulseStimulus(obj,pulseNum)
      % CREATEPULSESTIMULUS Generates pulse stimulus amplitude absolute
      persistent device
      if isempty(device)
        device = obj.rig.getDevice(obj.pulseDevice);
      elseif ~isempty(device) && ~isequal(device.name,obj.pulseDevice)
        device = obj.rig.getDevice(obj.pulseDevice);
      end
      
      pulseAmplitude = obj.pulseValues(pulseNum);
      pulseDuration = obj.pulseTime(pulseNum);
      pulseTail = obj.pulseTailTime(pulseNum);
      % pulsegenerator sets stim value as amplitude + mean
      pulseBackground = device.background.quantity;
      
      gen = symphonyui.builtin.stimuli.PulseGenerator();

      gen.preTime = obj.preTime + obj.pulseDelayTime;
      gen.stimTime = pulseDuration;
      gen.tailTime = pulseTail;
      gen.amplitude = pulseAmplitude-pulseBackground;
      gen.mean = pulseBackground;
      gen.sampleRate = obj.sampleRate;
      gen.units = device.background.displayUnits;
      
      stim = gen.generate();
      varargout{1} = stim;
      if nargout > 1
        varargout{2} = pulseAmplitude;
      end
      if nargout > 2
        varargout{3} = pulseDuration;
      end
      if nargout > 3
        varargout{4} = pulseTail;
      end
    end
    
    %%% Validation
    function value = validateLength(obj,value)
      n = obj.numberInFamily;
      nval = numel(value);
      if n > nval
        value(end+(1:(n-nval))) = value(end);
      elseif n < nval
        value((n+1):end) = [];
      end
    end
  end
  
  
  %% Other Administrative Methods
  methods
    
    function d = getPropertyDescriptor(obj, name)
      % GETPROPERTYDESCRIPTOR Override to control category on property grid
      d = getPropertyDescriptor@admin.core.LEDProtocol(obj,name);
      RecordControl = { ...
        'pulseDevice' ...
        };
      StimControl = { ...
        'pulseAmplitudes', 'stimValues', 'pulseValues' ...
        };
      RepControl = { ...
        'generatePulseFamily', 'generateLedFamily' ...
        };
      TemporalControl = { ...
        'pulseTime', 'pulseTailTime' ...
        };
      
      switch name
        case RecordControl
          d.category = '1. Recording Control';
          %%%
        case StimControl
          d.category = '2. Stimulus Control';
          %%%
        case TemporalControl
          d.category = '3. Temporal Controls';
          %%%
        case RepControl
          d.category = '4. Repetition Control';
          %%%
        otherwise % don't update
          %%%
      end
    end
    
    function [device,type] = createStimulusNamesProperty(obj)
      % CREATESTIMULUSNAMESPROPERTY Generate property field for non-led stimulus
      outputDevices = obj.rig.getOutputDevices();
      N = numel(outputDevices);
      nameList = cell(1,N);
      for d = 1:N
        dev = outputDevices{d};
        if isa(dev,'admin.core.devices.Device')
          if contains( ...
              dev.deviceType, ...
              ["oscilloscope","filter wheel","led"], ...
              'IgnoreCase', true ...
              )
            continue
          end
          nameList{d} = dev.name;
        elseif isa(dev,'admin.devices.Axopatch200B')
          nameList{d} = dev.name;
        elseif isa(dev, 'symphonyui.builtin.devices.AxopatchDevice')
          nameList{d} = dev.name;
        end
      end
      % drop unused slots
      nameList(cellfun(@isempty,nameList,'UniformOutput',true)) = [];
      if isempty(nameList)
        nameList = '(None}';
      end
      % set the values
      device = nameList{1};
      type = symphonyui.core.PropertyType('char', 'row', nameList);
    end
  end
end