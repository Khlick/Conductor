classdef Ramp < admin.core.Protocol
%% Amplifier Controls
  properties
    holdPotentialOverride = false % Check this box to override holding potential with Amp Hold (mV or pA)
    overrideCommand = 0             % Holding potential (mV or pA) if 'Hold Potential Override' is selected.
    initRampAmplitude = -80 % Initial potential (empirical; mV or pA). 
    finalRampAmplitude = 40 % Final potential (empirical; mV or pA).
  end
  properties(Dependent)
    rampTotalAmplitude      % Calculated total amplitude of ramp (mV).
  end
%% Temporal Controls
  properties
    preTime = 200           % Ramp leading duration (ms).
    rampDelay = 0           % Delay (ms) after step to initiate ramp interval.
    stimTime = 1000         % Ramp duration (ms).
    tailTime = 200          % Ramp trailing duration (ms).
  end
  properties (Dependent)
    totalEpochTime          % Calculated total recording length of each epoch
  end
%% Override Methods
  methods

    function didSetRig(obj)
      didSetRig@admin.core.Protocol(obj);
    end
    
    function setProperty(obj,name,value)
      switch name
        case 'delayBetweenEpochs'
          if ~isscalar(value)
            % delay is always constant
            value = value(1);
          end
      end
      setProperty@admin.core.Protocol(obj, name, value);
    end
    
    function p = getPreview(obj, panel)
      p = symphonyui.builtin.previews.StimuliPreview(panel, @()obj.createStimuli());
    end

    function prepareRun(obj)
      prepareRun@admin.core.Protocol(obj);
      
      hAmp = obj.rig.getDevice(obj.amp); % pointer to amplifier
      cm = admin.utils.getColorShades(1,obj.numberOfAverages,false);
      cm = permute(cm,[3,2,1]);% using single shades so squeeze into 2 dims

      obj.showFigure('admin.figures.Response', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'sweepColor', cm(1,:) ...
        );
      obj.showFigure('admin.figures.MeanResponse', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'colormapping', cm, ...
        'showEach', true ...
        );
      
      if obj.holdPotentialOverride
        bgQuant = obj.overrideCommand;
      else
        bgQuant = hAmp.background.quantity;
        obj.overrideCommand = bgQuant; %sets amp hold to current background levels
      end
      hAmp.background = symphonyui.core.Measurement(...
        bgQuant, ... %amplitude
        hAmp.background.displayUnits... %units
        );
    end

    function prepareEpoch(obj, epoch)
      prepareEpoch@admin.core.Protocol(obj, epoch);
      
      pulseNum = mod(obj.numEpochsPrepared-1,obj.numberOfAverages)+1;
      epoch.addParameter('pulseNumber', pulseNum);

      epoch.addStimulus(obj.rig.getDevice(obj.amp), obj.createStimuli());
      epoch.addResponse(obj.rig.getDevice(obj.amp));
    end
    
    function completeEpoch(obj,epoch)
      completeEpoch@admin.core.Protocol(obj,epoch);
    end
    
    function completeRun(obj)
      completeRun@admin.core.Protocol(obj);
    end
    
    function prepareInterval(obj, interval)
      prepareInterval@admin.core.Protocol(obj, interval);

      device = obj.rig.getDevice(obj.amp);
      interval.addDirectCurrentStimulus( ...
        device, ...
        device.background, ...
        obj.delayBetweenEpochs * 1e-3, ...
        obj.sampleRate ...
        );
    end

    function tf = shouldContinuePreparingEpochs(obj)
      tf = obj.numEpochsPrepared < obj.numberOfAverages;
    end

    function tf = shouldContinueRun(obj)
      tf = obj.numEpochsCompleted < obj.numberOfAverages;
    end

  end
  
%% Helper Methods
  methods
    %% get/set
    function t = get.totalEpochTime(obj)
      t = sum([obj.preTime,obj.rampDelay,obj.stimTime,obj.tailTime]);
    end
    
    function v = get.rampTotalAmplitude(obj)
      v = obj.finalRampAmplitude - obj.initRampAmplitude;
    end
    
    %% protocol routines
    function stimSum = createStimuli(obj)
      stim = cell(1,2);
      
      % some constants
      try
        bgUnits = obj.rig.getDevice(obj.amp).background.displayUnits;
      catch
        bgUnits = 'mV'; %for dev
      end
      try
        stimOffset = obj.rig.getDevice(obj.amp).background.quantity;
      catch
        stimOffset = 0; %for dev
      end
      
      % First generate Ramp
      rmp = symphonyui.builtin.stimuli.RampGenerator();

      rmp.preTime = obj.preTime + obj.rampDelay;
      rmp.stimTime = obj.stimTime;
      rmp.tailTime = obj.tailTime;
      rmp.amplitude = obj.rampTotalAmplitude;
      rmp.mean = 0;
      rmp.sampleRate = obj.sampleRate;
      rmp.units = bgUnits;

      stim{1} = rmp.generate(); %ramp
      
      % then generate Pulse
      pls = symphonyui.builtin.stimuli.PulseGenerator();
      
      pls.preTime = obj.preTime;
      pls.stimTime = obj.stimTime + obj.rampDelay;
      pls.tailTime = obj.tailTime;
      pls.amplitude = obj.initRampAmplitude - stimOffset;
      pls.mean = stimOffset;
      pls.sampleRate = obj.sampleRate;
      pls.units = bgUnits;
      
      stim{2} = pls.generate(); %step
      % Add the two pulses together
      sSum = symphonyui.builtin.stimuli.SumGenerator();
      
      sSum.stimuli = stim;
      stimSum = sSum.generate();
    end
  end

end

