classdef MultiStep < admin.core.Protocol
  %% Amplifier Controls
  properties
    holdPotentialOverride = false % Check this box to override holding potential with Amp Hold (mV or pA)
    overrideCommand = 0             % Holding potential (mV or pA) if 'Hold Potential Override' is selected.
  end
  %% Pulse Controls
  properties
    stepAmplitudes = [-80, 0] % Step amplitudes empircal (mV or pA)
    stepsAsFamily = uint16(1)    % Which step to be considered as a family
    familyIncrement = 10          % If any families, supply incremental volatge (mV)
  end
  properties (Dependent)
    familyMaxAmplitude
  end
  %% Temporal Controls
  properties
    preTime = 200              % Global leadin duration (ms)
    stimDurations = [100,100]  % Stimulation durations (ms)
    interstepIntervals = 0     % Delays between 1st and 2nd pulse(ms)
    tailTime = 200             % Global leadout duration (ms)
  end
  properties(Dependent)
    totalEpochTime
  end
  %% Repeating behavior
  properties
    numberInFamily = uint16(11)   % Number of epochs in each family
  end
  %% Display Controls
  properties (Hidden)
    stepAmplitudesType
    stimDurationsType
    interstepIntervalsType
    stepsAsFamilyType
    numberInFamilyType
  end
  %% Extra properties for stim creation
  properties (Hidden,Dependent)
    stimParam
  end
  %% Override Methods
  methods
    
    function didSetRig(obj)
      import symphonyui.core.PropertyType;
      didSetRig@admin.core.Protocol(obj)
      
      obj.stepAmplitudesType = PropertyType('denserealdouble','matrix');
      obj.stimDurationsType = PropertyType('denserealdouble','matrix');
      obj.interstepIntervalsType = PropertyType('denserealdouble','matrix');
      obj.setStepsAsFamilyType();
      obj.numberInFamilyType = PropertyType('uint16','scalar', [1 Inf]);
    end
    
    function setProperty(obj,name,value)
      import symphonyui.core.PropertyType;
      gp = {'stepAmplitudes', 'stimDurations'};
      
      switch name
        case 'stepsAsFamily'
          if value
            obj.numberInFamilyType = PropertyType('uint16','scalar', [1,Inf]);
          else
            obj.familyIncrement = 0;
            obj.numberInFamily = uint16(1);
            obj.numberInFamilyType = PropertyType('uint16','scalar', [1,1]);
          end
        case gp
          ad = ismember(gp,name);
          newLen = length(value);
          if newLen < 2
            obj.setProperty(name,[value,0]);
            warning('MultiStep protocol requires at least 2 steps.')
            return
          end
          oLen = length(obj.(gp{~ad}));
          if newLen > oLen
            obj.(gp{~ad})(end:end+(newLen-oLen)) = admin.utils.rep(...
              obj.(gp{~ad})(end),(newLen-oLen)+1, 'dims', {1,[]});
            obj.interstepIntervals(end:end+(newLen-oLen)) = admin.utils.rep(...
              obj.interstepIntervals(end), (newLen-oLen)+1,'dims',{1,[]});
          elseif newLen < oLen
            obj.(gp{~ad}) = obj.(gp{~ad})(1:(end-(oLen-newLen)));
            obj.interstepIntervals = obj.interstepIntervals(1:(end-(oLen-newLen)));
          end
          setProperty@admin.core.Protocol(obj,name,value);
          obj.setStepsAsFamilyType();
          obj.setProperty('delayBetweenEpochs',obj.delayBetweenEpochs);
          return
        case 'familyIncrement'
          if ~obj.stepsAsFamily
            value = 0;
          end
        case 'overrideCommand'
          if ~obj.holdPotentialOverride
            value = obj.overrideCommand;
          end
        case 'holdPotentialOverride'
          if ~value
            obj.overrideCommand = obj.rig.getDevice(obj.amp).background.quantity;
          end
        case 'interstepIntervals'
          ogVal = obj.getProperty(name);
          if length(value) ~= length(ogVal)
            value = ogVal;
            warning('Length of ''Interstep Interval'' cannot change.');
          end
        case 'delayBetweenEpochs'
          if ~isscalar(value)
            nVal = numel(value);
            nFam = obj.numberInFamily;
            if nVal > nFam
              value((nFam+1):end) = [];
            elseif nVal < nFam
              value(end + (1:(nFam-nVal))) = value(end);
            end
          end
      end
      setProperty@admin.core.Protocol(obj,name,value);
    end
    
    function p = getPreview(obj, panel)
      p = symphonyui.builtin.previews.StimuliPreview(panel, ...
        @()createPreviewStimuli(obj));
      function s = createPreviewStimuli(obj)
        s = cell(1, obj.numberInFamily);
        for i = 1:numel(s)
          s{i} = obj.createAmpStimulus(i);
        end
      end
    end
    
    function prepareRun(obj)
      prepareRun@admin.core.Protocol(obj);
      
      % Open figure handlers.
      hAmp = obj.rig.getDevice(obj.amp); % pointer to amplifier
      cm = admin.utils.getColorShades(1,obj.numberInFamily,false);
      cm = permute(cm,[3,2,1]);% using single shades so squeeze into 2 dims
      
      obj.showFigure( ...
        'admin.figures.Response',  ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'sweepColor', cm(1,:), ...
        'disableToolbar', true ...
        );
      
      obj.showFigure('admin.figures.MeanResponse', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'colormapping', cm, ...
        'showEach', true, ...
        'groupBy', {'stepAmplitude'} ...
        );
      
      if obj.holdPotentialOverride
        bgQuant = obj.overrideCommand;
      else
        bgQuant = hAmp.background.quantity;
        obj.overrideCommand = bgQuant; %sets amp hold to current background levels
      end
      hAmp.background = symphonyui.core.Measurement(...
        bgQuant, ... %amplitude
        hAmp.background.displayUnits... %units
        );
    end
    
    function prepareEpoch(obj, epoch)
      prepareEpoch@admin.core.Protocol(obj, epoch);
      
      pulseNum = mod(obj.numEpochsPrepared - 1, obj.numberInFamily) + 1;
      [stim, pulseAmplitude] = obj.createAmpStimulus(pulseNum);
      
      epoch.addParameter('stepNumber', pulseNum);
      epoch.addParameter('stepAmplitude', ...
        strjoin(cellfun(@num2str,num2cell(pulseAmplitude),'unif',0),';') ...
        );
      
      epoch.addStimulus(obj.rig.getDevice(obj.amp), stim);
      epoch.addResponse(obj.rig.getDevice(obj.amp));
    end
    
    function prepareInterval(obj, interval)
      prepareInterval@admin.core.Protocol(obj, interval);
      
      if isscalar(obj.delayBetweenEpochs)
        delayDuration = obj.delayBetweenEpochs * 1e-3;
      else
        pulseNum = mod(obj.numIntervalsPrepared - 1, obj.numberInFamily) + 1;
        delayDuration = obj.delayBetweenEpochs(pulseNum) * 1e-3;
      end
      
      device = obj.rig.getDevice(obj.amp);
      interval.addDirectCurrentStimulus( ...
        device, ...
        device.background, ...
        delayDuration, ...
        obj.sampleRate ...
        );
    end
    
    function completeEpoch(obj,epoch)
      completeEpoch@admin.core.Protocol(obj,epoch);
    end
    
    function completeRun(obj)
      completeRun@admin.core.Protocol(obj);
    end
    
    function tf = shouldContinuePreparingEpochs(obj)
      tf = obj.numEpochsPrepared < obj.numberOfAverages * obj.numberInFamily;
    end
    
    function tf = shouldContinueRun(obj)
      tf = obj.numEpochsCompleted < obj.numberOfAverages * obj.numberInFamily;
    end
    
  end
  
  %% Helper Methods
  methods
    %% get/set
    function r = get.familyMaxAmplitude(obj)
      if ~any(obj.stepsAsFamily)
        r = 0;
      else
        r = zeros(1,length(obj.stepsAsFamily));
        for l = 1:length(obj.stepsAsFamily)
          r(l) = obj.stepAmplitudes(double(obj.stepsAsFamily(l))) + ...
            (obj.numberInFamily-1) * obj.familyIncrement;
        end
        r = max(double(r));
      end
    end
    
    function t = get.totalEpochTime(obj)
      t = sum([obj.preTime,obj.stimDurations,obj.interstepIntervals, obj.tailTime]);
    end
    
    function s = get.stimParam(obj)
      ivs = [...
        obj.preTime, obj.interstepIntervals;...
        obj.stimDurations];
      ivs = reshape(cumsum(ivs(:)),2,[]);
      s = struct( ...
        'numPulses', length(obj.stepAmplitudes), ...
        'intervals', ...
          struct(...
            'lead', ivs(1,:),...
            'stim', obj.stimDurations,...
            'tail', obj.totalEpochTime - ivs(2,:) ...
            ),...
        'amplitudes', obj.stepAmplitudes ...
        );
    end
    
    %% protocol routines
    function setStepsAsFamilyType(obj)
      if obj.stepsAsFamily > length(obj.stepAmplitudes)
        obj.setProperty('stepsAsFamily', uint16(0));
      end
      obj.stepsAsFamilyType = symphonyui.core.PropertyType('uint16', 'scalar', ...
        num2cell(uint16(0:length(obj.stepAmplitudes))) ...
        );
    end
    
    function [s, pulseAmplitudes] = createAmpStimulus(obj, pulseNum)
      p = obj.stimParam;
      
      %Pre allocate cell for stim parameters
      s = cell(1,p.numPulses);
      pulseAmplitudes = zeros(1,p.numPulses);
      for st = 1:p.numPulses
        amplt = p.amplitudes(st);
        if st == double(obj.stepsAsFamily)
          amplt = amplt + (double(pulseNum)-1) * obj.familyIncrement;
        end
        
        try
          bgUnits = obj.rig.getDevice(obj.amp).background.displayUnits;
        catch
          bgUnits = 'mV';
        end
        try
          bgQuantity = obj.rig.getDevice(obj.amp).background.quantity;
        catch
          if obj.holdPotentialOverride
            bgQuantity = obj.overrideCommand;
          else
            bgQuantity = 0;
          end
        end
        
        pa = amplt - bgQuantity;
        
        if st~=1 %correct for summation of backgrounds
          bgQuantity = 0;
        end
        
        % generate
        gen = symphonyui.builtin.stimuli.PulseGenerator();
        
        gen.preTime = p.intervals.lead(st);
        gen.stimTime = p.intervals.stim(st);
        gen.tailTime = p.intervals.tail(st);
        gen.mean = bgQuantity;
        gen.amplitude = pa;
        gen.sampleRate = obj.sampleRate;
        gen.units = bgUnits;
        
        s{st} = gen.generate();
        pulseAmplitudes(st) = amplt;
      end
      % sum pulses together
      sSum = symphonyui.builtin.stimuli.SumGenerator();
      sSum.stimuli = s;
      s = sSum.generate();
    end
    
  end
end

