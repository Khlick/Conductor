classdef ResistanceAndCapacitance < admin.core.Protocol
  properties
    pulseAmplitude = 5.0            % Pulse amplitude (mV or pA)
  end
  %% Temporal Controls
  properties
    preTime = 15                    % Pulse leading duration (ms)
    stimTime = 30                   % Pulse duration (ms)
    tailTime = 15                   % Pulse trailing duration (ms)
  end
  properties (Dependent)
    totalEpochTime
  end
  %% Display Controls
  properties (Hidden)
    timeStamp
    sendToNotesType = symphonyui.core.PropertyType('logical','scalar');
  end
  properties
    sendToNotes = false
  end
  %% Transient Others
  properties (Transient = true,Hidden = true)
    cumulativeData
    recordingUnits
  end
  %% Override Methods
  methods
    
    function didSetRig(obj)
      import symphonyui.core.PropertyType;
      
      didSetRig@admin.core.Protocol(obj);
      obj.recordingUnits = '';
      obj.setProperty('numberOfAverages',uint16(15));
    end
    
    function setProperty(obj,name,value)
      switch name
        case 'delayBetweenEpochs'
          % rc always has constant delay between epochs
          if ~isscalar(value)
            value = value(1);
          end
      end
      setProperty@admin.core.Protocol(obj, name, value);
    end
    
    function p = getPreview(obj, panel)
      p = symphonyui.builtin.previews.StimuliPreview(panel, ...
        @()createAmpStimulus(obj));
    end
    
    function prepareRun(obj)
      prepareRun@admin.core.Protocol(obj);
      hAmp = obj.rig.getDevice(obj.amp);
      cm = admin.utils.getColorShades(1,obj.numberOfAverages,false);
      cm = permute(cm,[3,2,1]);% using single shades so squeeze into 2 dims
      % Open figure handlers.
      obj.showFigure('admin.figures.Response', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'sweepColor', cm(1,:) ...
        );
      obj.showFigure('admin.figures.MeanResponse', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'colormapping', cm, ...
        'showEach', true ...
        );
      
      obj.cumulativeData = zeros(obj.msToPts(obj.totalEpochTime),1);
    end
    
    function prepareEpoch(obj,epoch)
      prepareEpoch@admin.core.Protocol(obj,epoch);
      hAmp = obj.rig.getDevice(obj.amp);
      
      % add stim and response to the amplifier
      epoch.addStimulus(hAmp, obj.createAmpStimulus());
      epoch.addResponse(hAmp);
      
      % if oscilloscope exists and is on, send a special truncated pulse to it
      % rather that have it scroll in real time.
      if ismember('Oscilloscope',obj.rig.getDeviceNames')
        p = symphonyui.builtin.stimuli.PulseGenerator();
        
        p.preTime = 0;
        p.stimTime = 1;
        p.tailTime = obj.preTime + obj.stimTime + obj.tailTime - 1;
        p.amplitude = 1;
        p.mean = 0;
        p.sampleRate = obj.sampleRate;
        p.units = obj.rig.getDevice(...
          'Oscilloscope'...
          ).background.displayUnits;
        
        epoch.addStimulus(obj.rig.getDevice('Oscilloscope'), ...
          p.generate());
      end
    end
    
    function prepareInterval(obj,interval)
      prepareInterval@admin.core.Protocol(obj,interval);
      device = obj.rig.getDevice(obj.amp);
      interval.addDirectCurrentStimulus( ...
        device, ...
        device.background, ...
        obj.delayBetweenEpochs*1e-3, ...
        obj.sampleRate ...
        );
    end
    
    function completeEpoch(obj, epoch)
      completeEpoch@admin.core.Protocol(obj, epoch);
      
      response = epoch.getResponse(obj.rig.getDevice(obj.amp));
      [quantities,units] = response.getData();
      
      if isempty(obj.recordingUnits)
        obj.recordingUnits = units;
      end
      obj.cumulativeData = obj.cumulativeData(:) + quantities(:);
    end
    
    function tf = shouldContinuePreparingEpochs(obj)
      tf = obj.numEpochsPrepared < obj.numberOfAverages;
    end
    
    function tf = shouldContinueRun(obj)
      tf = obj.numEpochsCompleted < obj.numberOfAverages;
    end
    
    function completeRun(obj)
      completeRun@admin.core.Protocol(obj);
      obj.timeStamp = datestr(now,'YYYYmmmdd HH:MM:SS.FFF');
      obj.calculateRandC();
    end
    
  end
  
  %% Helper Methods
  methods
    
    function v = get.totalEpochTime(obj)
      v = obj.preTime + obj.stimTime + obj.tailTime;
    end
    
    function pts = msToPts(obj,t)
      pts = max(round(t / 1e3 * obj.sampleRate), 1);
    end
    
    function stim = createAmpStimulus(obj)
      hAmp = obj.rig.getDevice(obj.amp);
      bgUnits = hAmp.background.displayUnits;
      bgQuantity = hAmp.background.quantity;
      
      gen = symphonyui.builtin.stimuli.PulseGenerator();
      
      gen.preTime = obj.preTime;
      gen.stimTime = obj.stimTime;
      gen.tailTime = obj.tailTime;
      gen.amplitude = obj.pulseAmplitude;
      gen.mean = bgQuantity;
      gen.sampleRate = obj.sampleRate;
      gen.units = bgUnits;
      
      stim = gen.generate();
    end
    
    function calculateRandC(obj)
      %%% Collect responses and calculate resistance and capacitance
      
      % Get the data scale
      [prefix,~] = admin.utils.getPrefixFromUnits(obj.recordingUnits);
      exponent = admin.utils.prefixToExponent(prefix);
      dataScale = 10^exponent;
      
      hAmp = obj.rig.getDevice(obj.amp);
      [spx,sunt] = admin.utils.getPrefixFromUnits(hAmp.background.displayUnits);
      bgValue = hAmp.background.quantity;
      
      sExp = admin.utils.prefixToExponent(spx);
      V_delta = obj.pulseAmplitude * 10^sExp;
      
      %convenience
      prePts = obj.msToPts(obj.preTime);
      stimPts = obj.msToPts(obj.stimTime);
      totalPts = obj.msToPts(obj.totalEpochTime);
      
      sampleInterval = 1/obj.sampleRate *1e3; %ms
      
      % Mean data collected
      dat = [ ...
        ((1:totalPts)'-1) * sampleInterval, ... %ms
        obj.cumulativeData(:) / obj.numEpochsCompleted ...
        ];
      
      baseline = mean(dat(1:prePts,2));
      dat(:,2) = dat(:,2) - baseline;
      
      % get only the transient region
      dat = circshift(dat,-prePts-1,1);
      dat((stimPts+1):end,:) = [];
      % find transient peak
      [~,peakIdx] = max(dat(1:20,2),[],1);
      peakIdx = peakIdx(find(peakIdx == min(peakIdx),1,'first'));
      if peakIdx ~= 1
        dat(1:(peakIdx-1),:) = [];
      end
      
      % zero + dT
      tOfst = dat(1,1);
      dat(:,1) = dat(:,1) - tOfst + sampleInterval;
      
      i0Witdh = fix(0.2 * prePts);
      datRange = max(dat(:,2)) - min(dat(:,2));
      b0 = [ ...
        datRange, ...
        dat(find(rescale(dat(:,2)) <= 0.4,1,'first'),1), ...
        mean(dat((end-i0Witdh):end)) ...
        ];
      fitFunc = @(b,x)b(1)*exp(-x./b(2)) + b(3);
      v = ver;
      if ~any(strcmp('Curve Fitting Toolbox', {v.Name}))
        opts = optimset('MaxFunEvals', 100000, 'MaxIter', 100000);
        ols = @(b)sum((y(b,dat(:,1)) - dat(:,2)).^2);
        B = fminsearch(ols, p0, opts);
        fitType = 'LeastSquares';
      else
        ft = fittype( 'a*exp(-x/b)+c', 'independent', 'x', 'dependent', 'y' );
        curve = fit(dat(:,1),dat(:,2),ft,'StartPoint',b0);
        %curve = fit(dat(:,1),dat(:,2),ft,opts);
        B = coeffvalues(curve);
        fitType = 'toolbox';
      end
      
      % Extract parameters
      
      % fit paramater map:
      % B(1) = (I0 - Iss) => I0 = B(1) + Iss
      % B(2) = tau
      % B(3) = Iss
      
      tauCharge = B(2);
      tauCharge_s = tauCharge * 1e-3; %s
      iSS = B(3);
      iSteadyState = iSS * dataScale; %Ampere
      
      i0 = fitFunc(B,0) + iSS;
      i0_A = i0 * dataScale; %Ampere
      
      time_sec =  dat(:,1) * 1e-3;
      data_u = mean(dat(:,2:end),2);
      data_A = data_u * dataScale;
      % Access resistance (Series resistance)
      % ohm = Volt/Amp -> convert to MOhm
      Rs = (V_delta / i0_A)*1e-6;
      
      % Input Resistance (MOhm)
      % this is equivalent to Total Resistance at the tip
      Rin = (V_delta / iSteadyState) * 1e-6;
      
      % Membrane resistance (MOhm)
      % this is equivalent to the total resistance - access resistance
      % but also (dV - Raccess * iSS) / iSS;
      % Rm = (V_delta - Rs* 1e6 * iSteadyState) / iSteadyState *1e-6;
      Rm = Rin - Rs;
      
      % Calculate the parallel resistance
      Rp = Rs*Rm/(Rs+Rm);
      
      % Calculate the charge (Coulombs) of the transient.
      % Need to subtract the inverse exponential from the current response.
      % Integrate the data, subtract the integral of the correction data (dt)
      % Since coul = A*sec ( or C = integral( A*dt)
      chargeCorrectionData = iSteadyState * (1-exp(-time_sec/tauCharge_s)); %Ampere
      
      % integrate
      Qcorrection = trapz(time_sec,chargeCorrectionData); % Coulomb
      Qtotal = trapz(time_sec,data_A) - Qcorrection; % Coulomb
      
      % membrane capacitance (F)
      Cm_F = Qtotal/V_delta; % in F, since Coulomb/Volt = 1Farad
      Cm = Cm_F * 1e12; %pF
      
      % Total resistance (relative to tau) in MOhm
      % sec/Farad *1e-6 -> MOhm
      Rt = tauCharge_s/Cm_F * 1e-6;
      
      outputTxt = sprintf( ...
        [ '\n:: Membrane Parameters (% +3d% -2s) ::\n',   ...
        ' R_input   :   % 10.2f   % -6s \n', ...
        ' R_access  :   % 10.2f   % -6s \n', ...
        ' R_membrane:   % 10.2f   % -6s \n', ...
        ' R_parallel:   % 10.2f   % -6s \n', ...
        ' R_tau     :   % 10.2f   % -6s \n', ...
        ' C_membrane:   % 10.2f   % -6s \n', ...
        '        Tau:   % 10.2f   % -6s \n', ...
        '   FitType:    % -16s\n',           ...
        '::-----------------------------::\n'  ...
        ], ...
        bgValue, [spx,sunt], ...
        Rin, 'MOhm', ...
        Rs, 'MOhm', ...
        Rm, 'MOhm', ...
        Rp, 'MOhm', ...
        Rt, 'MOhm', ...
        Cm, 'pF', ...
        tauCharge, 'msec', ...
        fitType ...
        );
      fprintf(regexprep(outputTxt,'\\Omega', 'Ohm'));
      
      
      if obj.sendToNotes && ~isempty(obj.persistor)
        try
          experiment = obj.persistor.experiment;
          experiment.addNote(regexprep(outputTxt,'\\Omega', 'Ohm'));
        catch
          fprintf("Could not add note.\n");
        end
      end
    end
    
  end
end