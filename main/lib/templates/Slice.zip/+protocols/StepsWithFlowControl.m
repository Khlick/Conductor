classdef StepsWithFlowControl < admin.core.Protocol
  % StepsWithFlowControl A protocol to record responses to voltage/current steps.
  
  %% Amplifier Settings
  properties
    holdPotentialOverride = false % Check this box to override holding potential with Amp Hold (mV or pA)
    overrideCommand = 0             % Holding potential (mV or pA) if 'Hold Potential Override' is selected.
    firstPulse = -80                % First pulse signal value (mV or pA)
    incrementPerPulse = 10          % Increment/decrement value per each pulse (mV or pA)
  end
  properties (Dependent)
    finalPulse      % Final pulse voltage with given first, increment and # in family
  end
  %% Temporal controls
  properties
    preTime = 200                   % Pulse leading duration (ms)
    stimTime = 500                  % Pulse duration (ms)
    totalEpochTime = 1000           % Total recording length (ms)
  end
  properties (Dependent)
    tailTime                        % Pulse trailing duration (ms)
  end
  %% Repeating behavior
  properties
    asFamily = true                 % As family (1:nFam,1:nfam...) or not (1,1,1,2,2,2,3...)
    numberInFamily = uint16(11)     % Number of pulses in family
  end
  
  %% Other Devices
  properties
    flowChannel
    flowSwitchDelayOn = 1000%ms
    flowDuration  = 500%ms
  end
  properties (Dependent)
    flowFollowTime
  end
  %% Display controls
  properties (Hidden)
    asFamilyType
    numberInFamilyType
    flowChannelType
  end
  properties(Hidden,Dependent)
    numEpochs
  end
  
  %% Override methods
  methods
    
    function didSetRig(obj)
      import symphonyui.core.PropertyType;
      % call the superclass method
      didSetRig@admin.core.Protocol(obj);
      % assign types
      obj.numberInFamilyType = PropertyType('uint16', 'scalar', [1 Inf]);
      obj.asFamilyType = PropertyType('logical','scalar');
      [obj.flowChannel, obj.flowChannelType] = ...
        obj.createDeviceNamesProperty('VC8');
    end
    
    function setProperty(obj,name,value)
      switch name
        case 'delayBetweenEpochs'
          if ~isscalar(value)
            nVal = numel(value);
            nFam = obj.numberInFamily;
            if nVal > nFam
              value((nFam+1):end) = [];
            elseif nVal < nFam
              value(end + (1:(nFam-nVal))) = value(end);
            end
          end
      end
      setProperty@admin.core.Protocol(obj, name, value);
    end
    
    function p = getPreview(obj, panel)
      p = symphonyui.builtin.previews.StimuliPreview(panel, ...
        @()createPreviewStimuli(obj));
      function s = createPreviewStimuli(obj)
        s = cell(1, obj.numberInFamily);
        for i = 1:numel(s)
          s{i} = obj.createAmpStimulus(i);
        end
      end
    end
    
    function prepareRun(obj)
      prepareRun@admin.core.Protocol(obj);
      
      % Open figure handlers.
      hAmp = obj.rig.getDevice(obj.amp); % pointer to amplifier
      
      cm = admin.utils.getColorShades(1,obj.numberInFamily,false);
      cm = permute(cm,[3,2,1]);% using single shades so squeeze into 2 dims
      
      obj.showFigure( ...
        'admin.figures.Response',  ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'sweepColor', cm(1,:), ...
        'disableToolbar', true ...
        );
      
      obj.showFigure('admin.figures.MeanResponse', ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'colormapping', cm, ...
        'showEach', true, ...
        'groupBy', {'stepAmplitude'} ...
        );
      
      if obj.holdPotentialOverride
        bgQuant = obj.overrideCommand;
      else
        bgQuant = hAmp.background.quantity;
        obj.overrideCommand = bgQuant; %sets amp hold to current background levels
      end
      hAmp.background = symphonyui.core.Measurement(...
        bgQuant, ... %amplitude
        hAmp.background.displayUnits... %units
        );
    end
    
    function prepareEpoch(obj, epoch)
      % PREPAREEPOCH Superclass method increments numEpochsPrepared
      
      % increamemtn so that obj.numEpochsPrepared == this epoch number
      prepareEpoch@admin.core.Protocol(obj, epoch);
      
      % determine which pulse.
      if obj.asFamily
        pulseNum = mod(obj.numEpochsPrepared - 1, obj.numberInFamily) + 1;
      else
        fam = admin.utils.rep(1:obj.numberInFamily,1,obj.numberOfAverages);
        pulseNum = fam(obj.numEpochsPrepared);
      end
      % construct this stimulus
      [stim, pulseAmplitude] = obj.createAmpStimulus(pulseNum);
      
      % get the handle to the amplifier
      hAmp = obj.rig.getDevice(obj.amp);
      % add metadata we want to track to the epoch
      epoch.addParameter('stepAmplitude', pulseAmplitude);
      epoch.addParameter('stepUnits', hAmp.background.displayUnits);
      
      stimp = obj.createFlowStimulus();
      inverseStim = obj.createFlowStimulus(true);
      perfusionChannels = obj.flowChannelType;
      mainPerfusion = perfusionChannels.domain{ ...
        ~contains( ...
        perfusionChannels.domain, ...
        obj.flowChannel ...
        ) ...
        };
      
      % add the stimulus and response to the amplifier
      epoch.addStimulus(hAmp, stim);
      epoch.addResponse(hAmp);
      epoch.addStimulus(obj.rig.getDevice(obj.flowChannel), stimp);
      epoch.addStimulus(obj.rig.getDevice(mainPerfusion), inverseStim);
    end
    
    function prepareInterval(obj, interval)
      prepareInterval@admin.core.Protocol(obj, interval);
      
      if isscalar(obj.delayBetweenEpochs)
        delayDuration = obj.delayBetweenEpochs * 1e-3;
      else
        if obj.asFamily
          pulseNum = mod(obj.numIntervalsPrepared - 1, obj.numberInFamily) + 1;
        else
          fam = admin.utils.rep(1:obj.numberInFamily,1,obj.numberOfAverages);
          pulseNum = fam(obj.numIntervalsPrepared);
        end
        delayDuration = obj.delayBetweenEpochs(pulseNum) * 1e-3;
      end
      
      device = obj.rig.getDevice(obj.amp);
      interval.addDirectCurrentStimulus( ...
        device, ...
        device.background, ...
        delayDuration, ...
        obj.sampleRate ...
        );
    end
    
    function completeEpoch(obj,epoch)
      completeEpoch@admin.core.Protocol(obj,epoch);
      perfusionChannels = obj.flowChannelType;
      mainPerfusion = perfusionChannels.domain{ ...
        ~contains( ...
        perfusionChannels.domain, ...
        obj.flowChannel ...
        ) ...
        };
      obj.rig.getDevice(mainPerfusion).background = symphonyui.core.Measurement( ...
        1, ...
        obj.rig.getDevice(mainPerfusion).background.displayUnits ...
        );
      obj.rig.getDevice(mainPerfusion).applyBackground();
    end
    
    function completeRun(obj)
      completeRun@admin.core.Protocol(obj);
    end
    
    function tf = shouldContinuePreparingEpochs(obj)
      tf = obj.numEpochsPrepared < obj.numEpochs;
    end
    
    function tf = shouldContinueRun(obj)
      tf = obj.numEpochsCompleted < obj.numEpochs;
    end
    
  end
  
  %% Helper Methods
  methods
    
    % Stimulus Creation
    function [stim, pulseAmplitude] = createAmpStimulus(obj, pulseNum)
      % Some constants
      pulseAmplitude = obj.incrementPerPulse * (double(pulseNum) - 1) + obj.firstPulse;
      
      try
        bgUnits = obj.rig.getDevice(obj.amp).background.displayUnits;
      catch
        bgUnits = 'mV';
      end
      try
        bgQuantity = obj.rig.getDevice(obj.amp).background.quantity;
      catch
        bgQuantity = 0;
      end
      
      % generate
      gen = symphonyui.builtin.stimuli.PulseGenerator();
      
      gen.preTime = obj.preTime;
      gen.stimTime = obj.stimTime;
      gen.tailTime = obj.tailTime;
      gen.mean = bgQuantity;
      gen.amplitude = pulseAmplitude - gen.mean;
      gen.sampleRate = obj.sampleRate;
      gen.units = bgUnits;
      
      stim = gen.generate();
    end
    
    function stim = createFlowStimulus(obj,invert)
      if nargin < 2, invert = false; end
      if invert
        ampt = -1;
      else
        ampt = 1;
      end
      p = symphonyui.builtin.stimuli.PulseGenerator();
      
      p.preTime = obj.flowSwitchDelayOn;
      p.stimTime = obj.flowDuration;
      p.tailTime = obj.flowFollowTime;
      p.amplitude = ampt;
      p.mean = double(invert);
      p.sampleRate = obj.sampleRate;
      p.units = obj.rig.getDevice(...
        obj.flowChannel ...
        ).background.displayUnits;
      stim = p.generate();
    end
    
    %%% Get/Set
    
    function t = get.tailTime(obj)
      t = obj.totalEpochTime - (obj.stimTime+obj.preTime);
    end
    
    function t = get.flowFollowTime(obj)
      t = obj.totalEpochTime - (obj.flowSwitchDelayOn+obj.flowDuration);
    end
    
    function v = get.finalPulse(obj)
      v = obj.firstPulse+(obj.incrementPerPulse*(double(obj.numberInFamily)-1));
    end
    
    function n = get.numEpochs(obj)
      n = obj.numberOfAverages * obj.numberInFamily;
    end
  end
end

