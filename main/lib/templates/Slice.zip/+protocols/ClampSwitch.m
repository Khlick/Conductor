classdef ClampSwitch < admin.core.Protocol
  % CLAMPSWITCH A protocol to record V_rest and setting I=0 during clamp mode switching.
  
  properties
    duration = 300               % Set the total duration of each average.
    holdingCommand = 0           % Set holding command (mV -> VC; pA -> CC)
  end
  
  methods
    
    function didSetRig(obj)
      didSetRig@admin.core.Protocol(obj);
    end
    
    function setProperty(obj,name,value)
      switch name
        case 'delayBetweenEpochs'
          if ~isscalar(value)
            % must always be scalar
            value = value(1);
          end
      end
      setProperty@admin.core.Protocol(obj, name, value);
    end
    
    function p = getPreview(obj, panel)
      % generate the preview panel
      p = symphonyui.builtin.previews.StimuliPreview( ...
        panel, ...
        @() obj.generateStimulus() ...
        );
    end
    
    function prepareRun(obj)
      % PREPARERUN
      prepareRun@admin.core.Protocol(obj);
      
      % Open figure handlers.
      hAmp = obj.rig.getDevice(obj.amp);
      
      cm = admin.utils.getColorShades(1,obj.numberOfAverages);
      cm = permute(cm,[3,2,1]);% using single shades so squeeze into 2 dims
      
      % show all figures
      obj.showFigure( ...
        'admin.figures.ResponseWithFourier',  ...
        hAmp, ...
        'instanceId', 'Amplifier', ...
        'sweepColor', cm(1,:), ...
        'disableToolbar', true ...
        );
      if obj.numberOfAverages > 1
        obj.showFigure( ...
          'admin.figures.MeanResponseWithHistogram',  ...
          hAmp, ...
          'instanceId', 'Amplifier', ...
          'colorMapping', cm, ...
          'showEach', true ...
          );
      end
      
      % Set main amp hold signal.
      hAmp.background = symphonyui.core.Measurement( ...
        obj.holdingCommand, ...
        hAmp.background.displayUnits ...
        );
      % apply the background before starting the actual recording.
      hAmp.applyBackground();
    end
    
    function stim = generateStimulus(obj)
      hAmp = obj.rig.getDevice(obj.amp);
      background = hAmp.background;
      g = symphonyui.builtin.stimuli.DirectCurrentGenerator();
      g.offset = background.quantity;
      g.units = background.displayUnits;
      g.time = obj.duration * 1e-3;
      g.sampleRate = obj.sampleRate;
      stim = g.generate();
    end
    
    function prepareEpoch(obj, epoch)
      import symphonyui.core.Measurement;
      
      prepareEpoch@admin.core.Protocol(obj, epoch);
      
      % handle to the amplifier
      hAmp = obj.rig.getDevice(obj.amp);
      % add stimuli and responses
      epoch.addStimulus(hAmp,obj.generateStimulus());
      epoch.addResponse(hAmp);
    end
    
    function prepareInterval(obj, interval)
      prepareInterval@admin.core.Protocol(obj, interval);
      
      device = obj.rig.getDevice(obj.amp);
      interval.addDirectCurrentStimulus( ...
        device, ...
        device.background, ...
        obj.delayBetweenEpochs*1e-3, ... % convert ms to sec
        obj.sampleRate ...
        );
    end
    
    function completeEpoch(obj, epoch)
      completeEpoch@admin.core.Protocol(obj, epoch);
    end
    
    function completeRun(obj)
      completeRun@admin.core.Protocol(obj);
    end
    
    function tf = shouldContinuePreparingEpochs(obj)
      tf = obj.numEpochsPrepared < obj.numberOfAverages;
    end
    
    function tf = shouldContinueRun(obj)
      tf = obj.numEpochsCompleted < obj.numberOfAverages;
    end
    
  end
  
end

