classdef emptySource < symphonyui.core.persistent.descriptions.SourceDescription
  
  methods
    function obj = emptySource()
      import symphonyui.core.PropertyType;
            
      obj.addAllowableParentType([]); % restrict to top level soruce only
    end
  end
  
end

