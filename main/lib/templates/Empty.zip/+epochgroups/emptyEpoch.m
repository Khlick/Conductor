classdef emptyEpoch < symphonyui.core.persistent.descriptions.EpochGroupDescription
  
  methods
    
    function obj = emptyEpoch()
      import symphonyui.core.PropertyType;
      
      obj.addAllowableParentType([]); % Parent must be a source and not egroup.
    end
    
  end
  
end

