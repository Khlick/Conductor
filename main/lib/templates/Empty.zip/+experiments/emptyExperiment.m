classdef emptyExperiment < admin.descriptions.ExperimentDescription

  methods

    function obj = emptyExperiment()
      obj = obj@admin.descriptions.ExperimentDescription();
      
      import symphonyui.core.PropertyType;
      % Enter experiment details here
    end

  end

end

