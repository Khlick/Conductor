classdef GenericRig < admin.descriptions.RigDescription
  
  methods

    function createRig(obj)
      % GENERICRIG Empty rig
      
      import admin.devices.*;
      %{
      admin.devices contains the following custom devices: 
        ArduinoFilterWheel      
        Axopatch200B            
        DifferentialAmplifier   
        DummyWheel              
        GatedLed                
        GenericDevice           
        GenericIoAmplifierDevice
        LedDevice               
        ThorlabsFilterWheel     
      %}
      
      %%% BEGIN RIG DESCRIPTION

    end
    
  end

end

