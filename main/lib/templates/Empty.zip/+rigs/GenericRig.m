classdef GenericRig < admin.descriptions.RigDescription
  
  methods
    
    function createRig(obj)
      % GENERICRIG Empty rig
      
      import admin.devices.*
      import Symphony.Core.*
      %{
      admin.devices contains the following custom devices:
        ArduinoFilterWheel
        Axopatch200B
        DifferentialAmplifier
        DummyWheel
        GatedLed
        GenericDevice
        GenericIoAmplifierDevice
        LedDevice
        ThorlabsFilterWheel
      %}
      
      %%% BEGIN RIG DESCRIPTION
      daq = symphonyui.builtin.daqs.HekaDaqController();
      % Assign the daq to the rig
      obj.daqController = daq;
      map = struct();
      map.('amp_out')    = 'ao0';
      map.('amp_in')     = 'ai0';
      map.('amp_g')      = 'ai1';
      map.('amp_m')      = 'ai2';
      amp = Axopatch200B( ...
        'Axopatch200B', ...
        daq, ...
        'outputPort',             map.('amp_out'),  ...
        'scaledOutput',            map.('amp_in'),  ...
        'gainTelegraph',            map.('amp_g'),  ...
        'modeTelegraph',            map.('amp_m')   ...
        );
      obj.addDevice(amp);
    end
  end
  
end

